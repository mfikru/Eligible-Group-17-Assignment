"""Input validation shared by the Streamlit app and the FastAPI service."""
from __future__ import annotations

from .config import FORM_FIELDS


def validate_inputs(payload: dict, metadata: dict | None = None) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Errors block prediction; warnings do not.

    errors   - missing fields, wrong types, impossible values, unknown category,
               inconsistent years.
    warnings - value is possible but outside the range seen in training, so the
               model is extrapolating and the estimate is less reliable.
    """
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(payload, dict):
        return ["Input must be a dictionary of field names to values."], []

    for name, (label, kind, lo, hi, _default, _help) in FORM_FIELDS.items():
        if name not in payload or payload[name] is None or payload[name] == "":
            errors.append(f"Missing required field: {name}.")
            continue
        value = payload[name]

        if kind == "cat":
            if not isinstance(value, str):
                errors.append(f"{name} must be text.")
            elif metadata and value not in metadata.get("categorical_levels", {}).get(name, [value]):
                errors.append(f"{name} '{value}' is not a known Ames neighborhood code.")
            continue

        if isinstance(value, bool) or not isinstance(value, (int, float)):
            errors.append(f"{name} must be a number.")
            continue
        if value != value or value in (float("inf"), float("-inf")):
            errors.append(f"{name} must be a finite number.")
            continue
        if value < lo or value > hi:
            errors.append(f"{name} must be between {lo} and {hi} (got {value}).")
            continue

        if metadata and name in metadata.get("numeric_ranges", {}):
            tmin, tmax = metadata["numeric_ranges"][name]
            if value < tmin or value > tmax:
                warnings.append(f"{name}={value} is outside the training range "
                                f"({tmin:g}-{tmax:g}); the estimate may be unreliable.")

    # Cross-field rule
    if not errors and payload["YearRemodAdd"] < payload["YearBuilt"]:
        errors.append("YearRemodAdd cannot be earlier than YearBuilt.")

    return errors, warnings
