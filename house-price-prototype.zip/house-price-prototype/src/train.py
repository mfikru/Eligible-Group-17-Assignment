"""Train Linear Regression and Random Forest, log both to MLflow, save the best.

Usage:  python -m src.train --data data/train.csv
"""
from __future__ import annotations

import argparse
import json

import joblib
import mlflow
import mlflow.sklearn
import numpy as np
from sklearn.model_selection import train_test_split

from . import config
from .pipeline import build_model, compute_metrics, load_training_data


def build_metadata(X, best_name: str, metrics: dict) -> dict:
    """Everything the app/monitor needs besides the model itself."""
    numeric = X.select_dtypes(include="number")
    categorical = X.select_dtypes(exclude="number")
    reference = {}
    for col in config.MONITORED_FEATURES:
        if col in numeric:
            edges = np.unique(np.quantile(numeric[col].dropna(), np.linspace(0, 1, 11)))
            counts = np.histogram(numeric[col].dropna(), bins=edges)[0]
            reference[col] = {"edges": edges.tolist(),
                              "proportions": (counts / counts.sum()).tolist()}
    return {
        "best_model": best_name,
        "validation_metrics": metrics,
        "feature_columns": X.columns.tolist(),
        "numeric_defaults": numeric.median().to_dict(),
        "categorical_defaults": {c: categorical[c].mode().iloc[0] for c in categorical},
        "categorical_levels": {c: sorted(categorical[c].dropna().unique().tolist()) for c in categorical},
        "numeric_ranges": {c: [float(numeric[c].min()), float(numeric[c].max())] for c in numeric},
        "missing_rates": X.isna().mean().to_dict(),
        "reference_distributions": reference,
        "n_training_rows": int(len(X)),
    }


def main(data_path: str) -> dict:
    X, y = load_training_data(data_path)
    X_train, X_valid, y_train, y_valid = train_test_split(
        X, y, test_size=config.TEST_SIZE, random_state=config.RANDOM_STATE)

    mlflow.set_tracking_uri(config.MLFLOW_TRACKING_URI)
    mlflow.set_experiment(config.MLFLOW_EXPERIMENT)

    results, fitted = {}, {}
    for kind in ["LinearRegression", "RandomForest"]:
        with mlflow.start_run(run_name=kind):
            model = build_model(kind, X_train).fit(X_train, y_train)
            metrics = compute_metrics(y_valid, model.predict(X_valid))
            mlflow.log_params({"model_type": kind, "test_size": config.TEST_SIZE,
                               "random_state": config.RANDOM_STATE,
                               "n_train": len(X_train), "n_valid": len(X_valid),
                               "target_transform": "log1p"})
            mlflow.log_metrics(metrics)
            mlflow.sklearn.log_model(model, name="model", serialization_format="cloudpickle")
            results[kind], fitted[kind] = metrics, model
            print(f"{kind}: " + ", ".join(f"{k}={v:,.4f}" for k, v in metrics.items()))

    best = min(results, key=lambda k: results[k]["RMSLE"])  # lowest RMSLE wins
    print(f"Best model by validation RMSLE: {best}")

    # Refit the winner on ALL rows for the saved model; keep validation metrics for reporting.
    final = build_model(best, X).fit(X, y)
    config.MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(final, config.MODEL_PATH)
    config.METADATA_PATH.write_text(json.dumps(build_metadata(X, best, results[best]), indent=2))
    print(f"Saved {config.MODEL_PATH.name} and {config.METADATA_PATH.name}")
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/train.csv", help="Path to Kaggle Ames train.csv")
    main(ap.parse_args().data)
