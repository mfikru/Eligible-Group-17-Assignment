"""Load the saved model and turn form inputs into a price estimate."""
from __future__ import annotations

import csv
import json
import logging
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd

from . import config
from .validation import validate_inputs

config.APP_LOG.parent.mkdir(exist_ok=True)
logging.basicConfig(filename=config.APP_LOG, level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("house_price")


class ModelNotFoundError(RuntimeError):
    pass


def load_bundle():
    if not config.MODEL_PATH.exists() or not config.METADATA_PATH.exists():
        raise ModelNotFoundError(
            "Model files not found. Run `python -m src.train --data data/train.csv` first.")
    model = joblib.load(config.MODEL_PATH)
    metadata = json.loads(config.METADATA_PATH.read_text())
    return model, metadata


def build_row(payload: dict, metadata: dict) -> pd.DataFrame:
    """User fields + training defaults for every other feature, in training column order."""
    row = {**metadata["numeric_defaults"], **metadata["categorical_defaults"], **payload}
    return pd.DataFrame([row]).reindex(columns=metadata["feature_columns"])


def predict_price(payload: dict, model, metadata: dict, log_prediction: bool = True) -> dict:
    errors, warnings = validate_inputs(payload, metadata)
    if errors:
        log.warning("Rejected input: %s", errors)
        return {"ok": False, "errors": errors, "warnings": warnings}
    try:
        price = float(np.maximum(model.predict(build_row(payload, metadata))[0], 0))
    except Exception:  # unexpected failure: log details, return a safe message
        log.exception("Prediction failed")
        return {"ok": False, "errors": ["Prediction failed. The error was logged."], "warnings": warnings}

    # Rough band: +/- one validation RMSLE on the log scale (not a statistical guarantee).
    rmsle = metadata["validation_metrics"]["RMSLE"]
    result = {"ok": True, "prediction": round(price, 2),
              "low": round(price * float(np.exp(-rmsle)), 2),
              "high": round(price * float(np.exp(rmsle)), 2),
              "warnings": warnings}
    if log_prediction:
        _log_prediction(payload, result)
    return result


def _log_prediction(payload: dict, result: dict) -> None:
    """Append inputs + output (no personal data) so monitoring can check drift."""
    config.PREDICTION_LOG.parent.mkdir(exist_ok=True)
    new = not config.PREDICTION_LOG.exists()
    with open(config.PREDICTION_LOG, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["timestamp_utc", *config.FORM_FIELDS, "prediction"])
        w.writerow([datetime.now(timezone.utc).isoformat(),
                    *[payload[k] for k in config.FORM_FIELDS], result["prediction"]])
