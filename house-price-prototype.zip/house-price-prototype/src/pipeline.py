"""Data loading, preprocessing, models and metrics (mirrors the Module 5 notebook)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from .config import RANDOM_STATE


def load_training_data(path: str) -> tuple[pd.DataFrame, pd.Series]:
    df = pd.read_csv(path)
    if "SalePrice" not in df.columns:
        raise ValueError("train.csv must contain a 'SalePrice' column.")
    if df["SalePrice"].isna().any():
        raise ValueError("SalePrice contains missing values.")
    X = df.drop(columns=["SalePrice", "Id"], errors="ignore")  # Id is an identifier
    return X, df["SalePrice"]


def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    numeric = X.select_dtypes(include="number").columns.tolist()
    categorical = X.select_dtypes(exclude="number").columns.tolist()
    return ColumnTransformer([
        ("numeric", Pipeline([("imputer", SimpleImputer(strategy="median"))]), numeric),
        ("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical),
    ])


def build_model(kind: str, X: pd.DataFrame) -> TransformedTargetRegressor:
    """log1p target transform + preprocessing + regressor (as in the notebook)."""
    if kind == "LinearRegression":
        reg = LinearRegression()
    elif kind == "RandomForest":
        reg = RandomForestRegressor(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1)
    else:
        raise ValueError(f"Unknown model kind: {kind}")
    return TransformedTargetRegressor(
        regressor=Pipeline([("preprocessor", build_preprocessor(X)), ("model", reg)]),
        func=np.log1p, inverse_func=np.expm1,
    )


def compute_metrics(y_true, y_pred) -> dict[str, float]:
    y_pred = np.maximum(np.asarray(y_pred, dtype=float), 0)
    return {
        "RMSLE": float(np.sqrt(mean_squared_error(np.log1p(y_true), np.log1p(y_pred)))),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "R2": float(r2_score(y_true, y_pred)),
    }
