"""Shared configuration for the House Price prototype (Group 17)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = ROOT / "models" / "best_model.joblib"
METADATA_PATH = ROOT / "models" / "metadata.json"
PREDICTION_LOG = ROOT / "logs" / "predictions.csv"
APP_LOG = ROOT / "logs" / "app.log"

MLFLOW_TRACKING_URI = f"sqlite:///{ROOT / 'mlflow.db'}"
MLFLOW_EXPERIMENT = "Group17_Ames_House_Prices"

RANDOM_STATE = 42
TEST_SIZE = 0.2

# Fields a user types into the app. All other model features are filled with
# training-set medians / most-frequent values (see src/predict.py).
# name: (label, kind, min, max, default, help)
FORM_FIELDS = {
    "OverallQual":  ("Overall quality (1-10)", "int", 1, 10, 6, "Overall material and finish quality."),
    "GrLivArea":    ("Above-ground living area (sq ft)", "int", 300, 6000, 1500, "Ames training range: 334-5642."),
    "TotalBsmtSF":  ("Total basement area (sq ft)", "int", 0, 6500, 1000, "0 if no basement."),
    "GarageCars":   ("Garage capacity (cars)", "int", 0, 5, 2, "0 if no garage."),
    "FullBath":     ("Full bathrooms above ground", "int", 0, 5, 2, ""),
    "BedroomAbvGr": ("Bedrooms above ground", "int", 0, 10, 3, ""),
    "YearBuilt":    ("Year built", "int", 1870, 2026, 1990, ""),
    "YearRemodAdd": ("Year remodelled (same as built if none)", "int", 1870, 2026, 1990, ""),
    "LotArea":      ("Lot area (sq ft)", "int", 1000, 250000, 9000, "Ames training range: 1300-215245."),
    "Neighborhood": ("Neighborhood (Ames code)", "cat", None, None, "NAmes", "Must be one of the Ames neighborhoods."),
}

# Numeric features whose distribution is tracked for drift (monitoring/monitor.py)
MONITORED_FEATURES = ["OverallQual", "GrLivArea", "TotalBsmtSF", "GarageCars",
                      "YearBuilt", "LotArea"]
