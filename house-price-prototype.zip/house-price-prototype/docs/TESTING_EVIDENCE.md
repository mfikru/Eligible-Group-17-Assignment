# Testing Evidence (Task 2)

## What was tested
| Area | Tests | File |
|---|---|---|
| Input validation | valid input; missing field; wrong type; out-of-range; negative; NaN; unknown category; remodel before built; out-of-training-range warning; non-dict input | `tests/test_validation.py` |
| Training & prediction | both models train and metrics are finite; positive price and ordered range; higher quality → higher price (sanity); invalid input returns errors instead of crashing; column order; unseen category and missing values handled; prediction logging | `tests/test_pipeline.py` |
| Monitoring | no drift on same distribution; drift flagged when area distribution shifts; accuracy alert triggers retrain advice | `tests/test_monitor.py` |
| API | `/health`, `/predict` success; 422 for out-of-range, missing field, unknown neighborhood | `tests/test_api.py` |
| UI | Streamlit smoke tests: valid input shows an estimate; `OverallQual=99` shows an error | `tests/test_app.py` |

**Result:** 25 automated tests passed (`pytest -q`). The tests use **synthetic** data so they can run without the Kaggle file; they verify that the code behaves correctly, not that the model is accurate. Model accuracy comes from the Ames validation results in the README.

## Evidence to add before submitting (take these yourself)
- [ ] Screenshot of `pytest -q` output on your machine
- [ ] Screenshot of the Streamlit app with a valid input and the resulting estimate
- [ ] Screenshot of the app rejecting an invalid input
- [ ] Screenshot of the MLflow UI experiment table (RMSLE/RMSE/MAE/R² per run)
- [ ] Screenshot of the notebook's MLflow comparison table (after cleanup) and the loaded-model prediction vs. actual
- [ ] (Optional) screenshot of the `/docs` API page and a monitoring report
Save them in `docs/evidence/`.

## Real Ames data results (cleaned notebook and `src/train.py`, same split)
| Model | RMSLE | RMSE | MAE | R² |
|---|---|---|---|---|
| Linear Regression | 0.1419 | 25,418 | 16,970 | 0.916 |
| Random Forest | 0.1453 | 29,705 | 17,365 | 0.885 |

Model reloaded from MLflow, first 5 validation houses (actual → predicted): 154,500 → 154,182; 325,000 → 333,420; 115,000 → 99,767; 159,000 → 166,101; 315,500 → 340,880.

Example monitoring report (format demo on real held-out houses): `docs/evidence/monitoring_report_example.json`.
