# Submission Checklist: Module 6 (due Friday, November 6, 2026)

## You still need to do (I could not do these for you)
- [x] Trained on the real Kaggle `train.csv` and cleaned notebook executed on it (done; results in README)
- [ ] Re-run `python -m src.train` and `notebooks/module_6.ipynb` yourselves so screenshots show your own runs
- [ ] Confirm the Random Forest settings match your original experiment (see `docs/NOTEBOOK_CLEANUP.md`)
- [ ] Take the screenshots listed in `docs/TESTING_EVIDENCE.md` → `docs/evidence/`
- [ ] Fill in the `[brackets]` in README (members, responsibilities, links) and align "Purpose" with your Module 4 proposal
- [ ] Push to GitHub (public or reviewer-accessible); optionally deploy to Streamlit Community Cloud
- [ ] Record the video (≤ 10 min, ≤ 250 MB); in a group, every member speaks
- [ ] Convert Deliverables C and D to the format Canvas expects (Word/PDF) if required
- [ ] Verify the links work in a private browser window

## Deliverables
| | Item | File | Ready? |
|---|---|---|---|
| A | Project portfolio (ZIP/GitHub): code, README, evidence, monitoring plan, data statement | this folder | needs your screenshots and links |
| B | Video ≤ 10 min / 250 MB | (you record) | to do |
| C | One-page retrospective | `docs/DELIVERABLE_C_RETROSPECTIVE.md` | drafted: check it matches your experience |
| D | Simulated data statement | `docs/DELIVERABLE_D_SIMULATED_DATA_STATEMENT.md` | drafted |

## Final checks
- [ ] No passwords, API keys, credentials or confidential data (search the repo for "key", "token", "password")
- [ ] `data/train.csv`, `mlruns/`, `mlflow.db` and `logs/` are not committed (`.gitignore` handles this)
- [ ] Video states what is implemented, what is simulated, and what is future work
- [ ] All four deliverables uploaded to the Canvas assignment
