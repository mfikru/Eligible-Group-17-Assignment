# Limitations and Future Improvements

## Current limitations
1. **Narrow data:** 1,460 sales from Ames, Iowa (2006-2010). Not valid for other cities or today's market without new data.
2. **Single validation split:** results come from one 80/20 split (292 houses). No cross-validation, so the Linear vs. Random Forest gap (RMSLE 0.1419 vs. 0.1453) is small and may not be significant.
3. **Little tuning:** no hyperparameter tuning or cross-validation is shown in the notebook (its own text suggests them as next steps).
4. **Simplified app input:** users enter 10 of 79 features; the remaining 69 are filled with training medians/most-common values, so estimates for unusual houses can be off. (The model itself was evaluated with all 79 features.)
5. **Error is not small in dollars:** MAE ≈ $17k and RMSE ≈ $25k on houses averaging roughly $180k. Expensive houses and rare neighborhoods are likely worse.
6. **No fairness or segment audit**, no explainability, and no real-world outcome data to confirm live accuracy.
7. **Monitoring is a script, not a service:** nothing runs automatically; thresholds are rules of thumb.
8. **Not deployed publicly** (add link if you deploy to Streamlit Community Cloud).
9. **Notebook housekeeping** (see `NOTEBOOK_CLEANUP.md`).

## Realistic improvements
- 5-fold cross-validation and hyperparameter search; compare Ridge/Lasso and gradient boosting.
- Feature engineering (total square footage, house age, bathrooms total).
- Error analysis by neighborhood/price band; SHAP or permutation importance in the UI.
- Prediction intervals via quantile models or conformal prediction instead of the ±RMSLE band.
- Batch CSV upload with row-level validation; automatic weekly monitoring job.
- CI with GitHub Actions, Docker image, Streamlit Cloud deployment.
