# Notebook cleanup (module_6.ipynb)

**Status: all 11 issues below are fixed in `notebooks/module_6.ipynb`.** It was executed top to bottom on the real Ames `train.csv` (2 FINISHED runs, no duplicates, no errors) and is saved **with its real outputs**. The original is kept as `notebooks/module_6_original.ipynb`. One thing to check: your original Random Forest settings are not in the file, so the cleaned notebook uses 300 trees (RMSLE 0.1453 vs. 0.1452 originally; RMSE 29,705 vs. 28,880). Edit the `candidates` cell if you used other settings. Re-run it yourself (Colab: Restart and run all) so your screenshots show your own run.

Issues found in the original notebook and how each was fixed:

| # | Issue | Fix applied |
|---|---|---|
| 1 | The three runs shown in MLflow have status **FAILED** (cells "Recent runs") although metrics were logged | Restart runtime, run once top-to-bottom; confirm runs show FINISHED (or use `src/train.py`, which uses `with mlflow.start_run`) |
| 2 | Linear Regression is logged **twice** (duplicate row in the comparison table) | Delete old runs / run once on a fresh experiment |
| 3 | The cells that **define and train** `linear_model`, `linear_pipeline` and the **Random Forest** are missing from the export (Step 9/10 code is absent, but results appear) | Add the model-definition and training cells back so the notebook is reproducible |
| 4 | `best_model` is used in the Kaggle-submission cell but never defined | Load the best run: `best_model = mlflow.sklearn.load_model(f"runs:/{best_run_id}/model")` |
| 5 | Data is split **twice**; the second split keeps `Id` (80 columns), the first drops it (79) | Keep one split and always drop `Id` |
| 6 | RMSLE (the main metric) is logged for the models, but the visible Linear Regression cells only compute R², MAE and RMSE on `X_test` | Compute and log all four metrics with `evaluate_model` on one validation set |
| 7 | Experiment names differ: `Group_17_House_Prices` (test) vs. `Group17_Ames_House_Prices` | Keep the second; delete the test runs |
| 8 | Duplicate cells (`set_experiment` ×2, `search_runs` repeated) and an unused `fetch_california_housing` import | Remove |
| 9 | `test.csv` was not uploaded, so no submission file was produced | Optional: upload `test.csv` to demonstrate batch prediction |
| 10 | `artifact_path` is deprecated; pickle-format warning | Use `name="model"`; mention the security note in the maintenance plan |
| 11 | Depends on `google.colab` upload | Add a note, or load from `data/train.csv` locally |
