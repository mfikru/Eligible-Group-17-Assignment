# Simulated Data Statement: Group 17

**Does the project use simulated or synthetic data?**
**No** for training, evaluation and the demonstration. **Yes, only for automated testing** (see below).

## Real data used
- **Source:** the Ames Housing dataset as provided in the Kaggle competition "House Prices - Advanced Regression Techniques" (`train.csv`). The data were compiled by Dean De Cock (2011) from the Ames, Iowa Assessor's Office records.
- **Content:** 1,460 residential sales in Ames, Iowa (2006-2010), 79 property features, target `SalePrice`.
- **Privacy and confidentiality:** the dataset is public and contains no names, contact details or street addresses. The raw files are not included in the repository; users download them from Kaggle and must follow Kaggle's terms.
- **Use:** an 80/20 train/validation split (random_state=42) produced all reported metrics. These metrics describe historical Ames sales only. They are **not** evidence of real-world production performance.

## Synthetic data used (testing only)
- `tests/synthetic.py` generates a small random table (300 rows) with a few Ames-style columns and an artificial price formula.
- **Why:** so the automated tests can run anywhere without the Kaggle file and check that the code works (validation, training, prediction, monitoring, API).
- **What it is not:** it is not used to train the deployed model, to report accuracy, or in the demonstration. Any numbers it produces carry no meaning about real housing prices.

## Other simulated elements in the demonstration
- No live users, live outcome data or production traffic exist. The monitoring plan and drift script are demonstrated with synthetic or logged demo inputs and are described as a proposal for production use.
- Prediction logs created during the demo come from group members testing the app.

No passwords, API keys, credentials or confidential data are included in the submission.
