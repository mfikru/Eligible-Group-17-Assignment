# Monitoring, Support & Maintenance Plan (Task 3)

*Scope: a proposed plan for moving the prototype toward practical use. Only the pieces marked
**[implemented]** exist in this repository; everything else is a proposal.*

## 1. Performance monitoring
| What | How | Threshold | Status |
|---|---|---|---|
| Prediction accuracy | When a property sells, join the actual price to the logged estimate and compute RMSLE/MAE (`monitoring.monitor --outcomes`) | Alert if live RMSLE > 1.25 × validation RMSLE (0.1419 → 0.177) | **[implemented]** script; needs real outcomes |
| Input drift | Population Stability Index per key feature vs. training deciles | PSI ≥ 0.10 warn, ≥ 0.25 alert | **[implemented]** |
| Data quality | Share of inputs outside the training range; rejected-input rate | > 5 % out of range → warn | **[implemented]** |
| Segment accuracy | Report error by neighborhood and price band, not just overall | Any segment error > 1.5 × overall → investigate | Proposed |
| Usage & latency | Request count, response time, error rate | p95 latency > 2 s, error rate > 2 % | Proposed |
Cadence: weekly report, monthly review meeting, immediate review on any alert.

## 2. Error handling
- **Application errors:** validation errors are shown to the user and logged as WARNING; unexpected exceptions are logged with a stack trace in `logs/app.log` and the user gets a safe message **[implemented]**. Proposed: alert the owner when the error rate crosses 2 %.
- **Unexpected predictions:** flag estimates that are far from a simple baseline (e.g. price per sq ft outside the neighborhood's historical range), and show out-of-range warnings **[partially implemented]**. Flagged cases go to a human reviewer rather than being silently accepted.
- **Triage:** each report is logged as an issue (see §5) with input, expected vs. actual, severity (S1 wrong/unsafe output, S2 feature broken, S3 cosmetic).

## 3. Data and model updates
1. **Collect:** append new sales (with the actual price) to a versioned dataset; record the source and date.
2. **Evaluate:** score the current model on the newest sales it has never seen (a time-based hold-out, not a random split) and compare with the validation baseline.
3. **Retrain when any of:** live RMSLE alert; PSI alert on ≥ 2 key features; ≥ 6 months since last training; a schema change.
4. **Candidate vs. champion:** train with `src/train.py` (every run logged to MLflow with parameters, metrics, data version) and promote the candidate only if it beats the current model on the time-based hold-out and shows no segment regression.
5. **Release & rollback:** tag the release in Git, keep the previous `best_model.joblib`, and roll back if post-release metrics worsen.
Important: the training data cover Ames, Iowa 2006-2010. Using the model for any other market/period would require new data, not just retraining.

## 4. Security and responsible AI
- **Privacy:** the Ames data contain no names or addresses; the app logs only property attributes, never personal details. If real client data were added, apply data minimisation, access control, encryption in transit/at rest and a retention limit.
- **Secrets:** no keys or credentials in the repo (`.gitignore` blocks `.env`/keys); in deployment use environment variables or a secrets manager.
- **Model-file safety:** `joblib`/`cloudpickle` files can execute code when loaded. Only load files produced by our own pipeline, keep them in access-controlled storage, and consider the `skops` format or checksums. (MLflow warned about this in the notebook.)
- **API hardening (proposed):** HTTPS, authentication, rate limiting; input is already schema-validated.
- **Fairness:** house prices can encode neighborhood-level inequality and historical bias. Proposed: audit errors by neighborhood and price tier; never use the estimate as the sole basis for lending, insurance or tax decisions; keep a human in the loop.
- **Transparency:** the UI states the data source, the model's validation error, that unspecified features use typical values, and that the output is not a professional valuation.

## 5. Support and maintenance
- **Problem tracking:** GitHub Issues with a template (what happened, input, expected vs. actual, severity); link each fix to a pull request and a test that reproduces the bug.
- **Defects:** every fix adds a regression test; CI (proposed GitHub Actions) runs `pytest` on each pull request.
- **Dependencies:** pin versions in `requirements.txt`; monthly dependency check (e.g. Dependabot) and security-advisory review; re-run the tests after each upgrade.
- **Documentation:** keep README, this plan and a changelog current; record each model version, data version and metrics in MLflow.
- **Roadmap (see `LIMITATIONS.md`):** cross-validation and tuning, gradient-boosting comparison, explanations (feature importance/SHAP), more input features, batch upload, containerised deployment with CI/CD.
