from fastapi.testclient import TestClient

import api
from tests.test_validation import GOOD


def test_health_and_predict(trained):
    model, metadata, _ = trained
    api._bundle = (model, metadata)           # use the synthetic-trained model
    c = TestClient(api.app)
    assert c.get("/health").json() == {"status": "ok"}
    r = c.post("/predict", json=GOOD)
    assert r.status_code == 200 and r.json()["prediction"] > 0


def test_api_rejects_bad_input(trained):
    model, metadata, _ = trained
    api._bundle = (model, metadata)
    c = TestClient(api.app)
    assert c.post("/predict", json={**GOOD, "OverallQual": 50}).status_code == 422
    assert c.post("/predict", json={"OverallQual": 5}).status_code == 422
    assert c.post("/predict", json={**GOOD, "Neighborhood": "Atlantis"}).status_code == 422
