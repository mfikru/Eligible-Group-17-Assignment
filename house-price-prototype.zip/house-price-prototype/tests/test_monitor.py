import pandas as pd

from monitoring.monitor import build_report, psi
from tests.synthetic import make_synthetic


def test_no_drift_on_same_distribution(trained):
    _, metadata, _ = trained
    log = make_synthetic(300, seed=1)
    report = build_report(log, metadata)
    assert all(v < 0.1 for v in report["drift"].values())


def test_drift_detected_when_area_doubles(trained):
    _, metadata, _ = trained
    log = make_synthetic(300, seed=2)
    log["GrLivArea"] = log["GrLivArea"] * 2 + 1000
    report = build_report(log, metadata)
    assert report["drift"]["GrLivArea"] > 0.25
    assert any("GrLivArea" in a and "ALERT" in a for a in report["alerts"])


def test_live_accuracy_alert(trained):
    _, metadata, _ = trained
    outcomes = pd.DataFrame({"actual_price": [100000] * 40, "prediction": [200000] * 40})
    report = build_report(make_synthetic(50, seed=3), metadata, outcomes)
    assert any("retrain" in a for a in report["alerts"])
