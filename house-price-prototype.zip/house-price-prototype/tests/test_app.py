"""Streamlit UI smoke tests (use the synthetic-trained model from conftest)."""
from streamlit.testing.v1 import AppTest


def test_app_valid_input_shows_estimate(trained):
    at = AppTest.from_file("../app.py", default_timeout=30).run()
    assert not at.exception
    at.button[0].click().run()
    assert at.success and "Estimated sale price" in at.success[0].value


def test_app_invalid_input_shows_error(trained):
    at = AppTest.from_file("../app.py", default_timeout=30).run()
    at.number_input[0].set_value(99)          # OverallQual must be 1-10
    at.button[0].click().run()
    assert at.error and "OverallQual" in at.error[0].value
