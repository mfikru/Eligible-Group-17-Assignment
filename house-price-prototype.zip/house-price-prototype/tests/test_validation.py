import copy

from src.validation import validate_inputs

META = {"categorical_levels": {"Neighborhood": ["NAmes", "OldTown"]},
        "numeric_ranges": {"GrLivArea": [334, 5642]}}
GOOD = {"OverallQual": 6, "GrLivArea": 1500, "TotalBsmtSF": 1000, "GarageCars": 2, "FullBath": 2,
        "BedroomAbvGr": 3, "YearBuilt": 1990, "YearRemodAdd": 1995, "LotArea": 9000,
        "Neighborhood": "NAmes"}


def check(**changes):
    p = copy.deepcopy(GOOD); p.update(changes)
    return validate_inputs(p, META)


def test_valid_input_has_no_errors():
    assert check() == ([], [])

def test_missing_field():
    p = copy.deepcopy(GOOD); del p["GrLivArea"]
    errors, _ = validate_inputs(p, META)
    assert any("GrLivArea" in e for e in errors)

def test_wrong_type():
    assert check(OverallQual="high")[0]

def test_out_of_range_quality():
    assert check(OverallQual=11)[0]

def test_negative_area():
    assert check(GrLivArea=-50)[0]

def test_nan_rejected():
    assert check(LotArea=float("nan"))[0]

def test_unknown_neighborhood():
    assert check(Neighborhood="Atlantis")[0]

def test_remodel_before_built():
    assert any("YearRemodAdd" in e for e in check(YearBuilt=2000, YearRemodAdd=1990)[0])

def test_outside_training_range_is_warning_not_error():
    errors, warnings = check(GrLivArea=5900)
    assert errors == [] and warnings

def test_non_dict_input():
    assert validate_inputs("not a dict")[0]
