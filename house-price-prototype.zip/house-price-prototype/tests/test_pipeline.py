import math

import pandas as pd

from src.predict import build_row, predict_price
from tests.test_validation import GOOD


def test_both_models_trained_and_best_saved(trained):
    _, metadata, results = trained
    assert set(results) == {"LinearRegression", "RandomForest"}
    assert metadata["best_model"] in results
    assert all(math.isfinite(v) for v in results[metadata["best_model"]].values())


def test_prediction_is_positive_and_band_ordered(trained):
    model, metadata, _ = trained
    r = predict_price(GOOD, model, metadata, log_prediction=False)
    assert r["ok"] and r["prediction"] > 0 and r["low"] < r["prediction"] < r["high"]


def test_higher_quality_gives_higher_price(trained):
    model, metadata, _ = trained
    lo = predict_price({**GOOD, "OverallQual": 3}, model, metadata, log_prediction=False)
    hi = predict_price({**GOOD, "OverallQual": 9}, model, metadata, log_prediction=False)
    assert hi["prediction"] > lo["prediction"]


def test_invalid_input_returns_errors_not_exception(trained):
    model, metadata, _ = trained
    r = predict_price({**GOOD, "OverallQual": 99}, model, metadata, log_prediction=False)
    assert not r["ok"] and r["errors"]


def test_row_has_training_columns_in_order(trained):
    _, metadata, _ = trained
    row = build_row(GOOD, metadata)
    assert list(row.columns) == metadata["feature_columns"] and len(row) == 1


def test_unseen_category_in_raw_model_does_not_crash(trained):
    model, metadata, _ = trained
    row = build_row(GOOD, metadata)
    row["Alley"] = "NeverSeenBefore"
    assert math.isfinite(model.predict(row)[0])


def test_missing_values_are_imputed(trained):
    model, metadata, _ = trained
    row = build_row(GOOD, metadata)
    row["LotFrontage"] = float("nan")
    assert math.isfinite(model.predict(row)[0])


def test_prediction_is_logged(trained, tmp_path):
    from src import config
    model, metadata, _ = trained
    predict_price(GOOD, model, metadata)
    df = pd.read_csv(config.PREDICTION_LOG)
    assert len(df) >= 1 and "prediction" in df
