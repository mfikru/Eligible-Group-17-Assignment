import pytest

from src import config, train
from tests.synthetic import make_synthetic


@pytest.fixture(scope="session")
def trained(tmp_path_factory):
    """Train on SYNTHETIC data into a temp folder so real model files are never touched."""
    tmp = tmp_path_factory.mktemp("run")
    config.MODEL_PATH = tmp / "best_model.joblib"
    config.METADATA_PATH = tmp / "metadata.json"
    config.PREDICTION_LOG = tmp / "predictions.csv"
    config.MLFLOW_TRACKING_URI = f"sqlite:///{tmp / 'mlflow.db'}"
    csv = tmp / "synthetic_train.csv"
    make_synthetic().to_csv(csv, index=False)
    results = train.main(str(csv))
    from src.predict import load_bundle
    model, metadata = load_bundle()
    return model, metadata, results
