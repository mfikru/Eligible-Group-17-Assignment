"""SYNTHETIC data generator used ONLY for automated tests and for checking that the code runs.
It is NOT the real Ames data and results from it say nothing about real performance."""
import numpy as np
import pandas as pd

NEIGHBORHOODS = ["NAmes", "CollgCr", "OldTown", "Edwards", "Somerst"]


def make_synthetic(n: int = 300, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    qual = rng.integers(1, 11, n)
    area = rng.integers(500, 3500, n)
    built = rng.integers(1900, 2010, n)
    df = pd.DataFrame({
        "Id": np.arange(1, n + 1),
        "OverallQual": qual,
        "GrLivArea": area,
        "TotalBsmtSF": rng.integers(0, 2000, n),
        "GarageCars": rng.integers(0, 4, n),
        "FullBath": rng.integers(1, 4, n),
        "BedroomAbvGr": rng.integers(1, 6, n),
        "YearBuilt": built,
        "YearRemodAdd": built + rng.integers(0, 20, n),
        "LotArea": rng.integers(2000, 20000, n),
        "LotFrontage": np.where(rng.random(n) < 0.15, np.nan, rng.integers(30, 120, n)),
        "Neighborhood": rng.choice(NEIGHBORHOODS, n),
        "Alley": np.where(rng.random(n) < 0.9, None, "Pave"),
    })
    df["SalePrice"] = (20000 + qual * 12000 + area * 55 + (built - 1900) * 150
                       + rng.normal(0, 10000, n)).clip(30000).round()
    return df
