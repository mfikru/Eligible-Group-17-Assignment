# Data

`train.csv` (and `test.csv`) are **not committed**. Download them from the Kaggle competition
"House Prices - Advanced Regression Techniques" (Ames Housing dataset, De Cock 2011) and place
`train.csv` in this folder. Check the Kaggle competition rules before redistributing the files.
