"""Simple monitoring report: data quality, drift (PSI) and, when outcomes exist, accuracy.

Usage:
  python -m monitoring.monitor --log logs/predictions.csv
  python -m monitoring.monitor --log logs/predictions.csv --outcomes logs/outcomes.csv
      (outcomes.csv needs columns: prediction, actual_price)
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd

from src import config
from src.pipeline import compute_metrics

PSI_WARN, PSI_ALERT = 0.10, 0.25   # common rule-of-thumb thresholds
RMSLE_ALERT_FACTOR = 1.25          # alert if live RMSLE > 1.25 x validation RMSLE


def psi(reference: dict, values: pd.Series) -> float:
    edges = np.array(reference["edges"], dtype=float)
    edges[0], edges[-1] = -np.inf, np.inf
    actual = np.histogram(values.dropna(), bins=edges)[0].astype(float)
    actual = np.clip(actual / max(actual.sum(), 1), 1e-4, None)
    expected = np.clip(np.array(reference["proportions"]), 1e-4, None)
    return float(np.sum((actual - expected) * np.log(actual / expected)))


def build_report(log_df: pd.DataFrame, metadata: dict, outcomes: pd.DataFrame | None = None) -> dict:
    report = {"n_predictions": int(len(log_df)), "alerts": [], "drift": {}, "quality": {}}
    if len(log_df) < 30:
        report["alerts"].append("INFO: fewer than 30 logged predictions; drift scores are unreliable.")

    for col, ref in metadata.get("reference_distributions", {}).items():
        if col in log_df:
            score = psi(ref, log_df[col])
            report["drift"][col] = round(score, 4)
            if score >= PSI_ALERT:
                report["alerts"].append(f"ALERT: {col} drifted (PSI={score:.2f}).")
            elif score >= PSI_WARN:
                report["alerts"].append(f"WARN: {col} shifting (PSI={score:.2f}).")

    ranges = metadata.get("numeric_ranges", {})
    for col, (lo, hi) in ranges.items():
        if col in log_df and len(log_df):
            out = float(((log_df[col] < lo) | (log_df[col] > hi)).mean())
            report["quality"][f"{col}_out_of_training_range"] = round(out, 4)
            if out > 0.05:
                report["alerts"].append(f"WARN: {out:.0%} of {col} values outside training range.")

    if outcomes is not None and len(outcomes):
        live = compute_metrics(outcomes["actual_price"], outcomes["prediction"])
        report["live_metrics"] = live
        base = metadata["validation_metrics"]["RMSLE"]
        if live["RMSLE"] > RMSLE_ALERT_FACTOR * base:
            report["alerts"].append(
                f"ALERT: live RMSLE {live['RMSLE']:.3f} > {RMSLE_ALERT_FACTOR}x baseline {base:.3f}; "
                "consider retraining.")
    return report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", default=str(config.PREDICTION_LOG))
    ap.add_argument("--outcomes")
    args = ap.parse_args()
    meta = json.loads(config.METADATA_PATH.read_text())
    out = pd.read_csv(args.outcomes) if args.outcomes else None
    print(json.dumps(build_report(pd.read_csv(args.log), meta, out), indent=2))
