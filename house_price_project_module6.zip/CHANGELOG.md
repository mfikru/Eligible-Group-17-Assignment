# Changelog

## Module 6
**Added**
- `prediction_log.py`: SQLite prediction log (inputs, estimate, range, warnings, model version, response time) and recorded real sale prices. No personal data. `PRICE_LOG=0` switches it off.
- `api.py`: FastAPI REST API (`/predict`, `/outcome`, `/health`, `/model-info`) using the same validation and model as the app.
- `monitoring.py`: operations, data-drift (PSI) and accuracy reports with alert thresholds; `models/reference_stats.json` (written by `train.py`).
- `evaluate_app_inputs.py`: clean held-out accuracy of the 13-field form → `reports/app_input_holdout.json`.
- `fairness_audit.py`: error and bias by neighbourhood and price band.
- `log_to_mlflow.py`: optional MLflow mirror of the experiment logs.
- `simulate_traffic.py`: SIMULATED traffic to demonstrate monitoring.
- `artifacts.py`: shared model loading, model version fingerprint, form baseline.
- Docker: `Dockerfile.api`, `docker-compose.yml`, `.dockerignore`; `requirements-api.txt`, `requirements-mlops.txt`; `.github/workflows/ci.yml`.
- Tests: 40 new unit/API tests (59 total); 8 new system tests (39 total).

**Changed**
- App: logs each distinct request, "record the real sale price" box, privacy note, and honest accuracy figures for the 13-field form.
- The typical range now uses the form's own error (±14%, was ±11%): the old range held only 65% of held-out homes through the form.
- `Dockerfile` now copies the new modules (the old one would have failed to start the app).
- `train.py` also writes the drift reference file.

**Fixed**
- Validation accepted a number, list or object as the neighbourhood (only reachable through the API) and produced an estimate. It now rejects non-text and over-long values.
