"""SIMULATED traffic for demonstrating the monitoring tools (there is no real user traffic in a prototype).

    python simulate_traffic.py --scenario normal   # replays the 292 held-out homes with their real sale prices
    python simulate_traffic.py --scenario drift    # a SIMULATED market change: bigger, newer homes and prices 40% higher

IMPORTANT, when presenting results:
  * Everything here is replayed or simulated, and is NOT evidence of real-world performance.
  * The saved model was refitted on all 1,458 homes, so it has seen the held-out homes; 'normal' accuracy is optimistic.
    The baseline used here is the form's clean held-out accuracy (reports/app_input_holdout.json).
  * 'drift' invents a market change (x1.25 living area, +1 quality, 40% higher prices, shifted neighbourhood mix).
Requests go to a separate demo database, never to the real log (logs/predictions.db).
"""
from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

import numpy as np
import pandas as pd

os.environ["PRICE_LOG"] = "1"
import artifacts  # noqa: E402
import housing as h  # noqa: E402
import monitoring  # noqa: E402
import prediction_log as plog  # noqa: E402

ROOT = Path(__file__).parent
NEW_BUILD = ["NridgHt", "Somerst", "NoRidge", "StoneBr", "Timber", "Gilbert"]


def to_inputs(r: pd.Series) -> dict:
    return {"Neighborhood": r["Neighborhood"], "GrLivArea": int(r["GrLivArea"]), "Stories": 2 if r["2ndFlrSF"] > 0 else 1,
            "LotArea": int(r["LotArea"]), "OverallQual": int(r["OverallQual"]), "OverallCond": int(r["OverallCond"]),
            "YearBuilt": int(r["YearBuilt"]), "YearRemodAdd": int(r["YearRemodAdd"]), "GarageCars": int(r["GarageCars"]),
            "TotalBsmtSF": int(r["TotalBsmtSF"]), "FullBath": int(r["FullBath"]), "HalfBath": int(r["HalfBath"]),
            "KitchenQual": r["KitchenQual"]}


def scenario_frame(scenario: str, n: int, seed: int) -> pd.DataFrame:
    homes = pd.read_csv(ROOT / "reports/test_predictions.csv")
    rng = np.random.default_rng(seed)
    if scenario == "normal":
        return homes.sample(min(n, len(homes)), random_state=seed).reset_index(drop=True)
    w = np.where(homes["Neighborhood"].isin(NEW_BUILD), 4.0, 1.0)
    d = homes.sample(n, replace=True, weights=w, random_state=seed).reset_index(drop=True)
    d["GrLivArea"] = (d["GrLivArea"] * 1.25).round()
    d["OverallQual"] = (d["OverallQual"] + 1).clip(upper=10)
    d["YearBuilt"] = (d["YearBuilt"] + rng.integers(5, 25, len(d))).clip(upper=h.SALE_YEAR)
    d["YearRemodAdd"] = np.maximum(d["YearRemodAdd"], d["YearBuilt"])
    d["SalePrice"] = d["SalePrice"] * 1.40
    return d


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", choices=["normal", "drift"], default="normal")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    db = ROOT / f"logs/demo_{a.scenario}.db"
    db.parent.mkdir(exist_ok=True)
    db.unlink(missing_ok=True)
    model, defaults, info = artifacts.load_artifacts()
    version = artifacts.model_version()
    for _, row in scenario_frame(a.scenario, a.n, a.seed).iterrows():
        inputs = to_inputs(row)
        t0 = time.perf_counter()
        out = h.safe_estimate(model, defaults, inputs, artifacts.range_rmsle(info))
        ms = (time.perf_counter() - t0) * 1000
        rid = plog.log_prediction(inputs, out, source="simulated", model_version=version, latency_ms=ms, path=db)
        if rid and out["ok"]:
            plog.log_outcome(rid, float(row["SalePrice"]), path=db)

    title = f"SIMULATED monitoring demo: {a.scenario} scenario"
    text, alerts = monitoring.make_report(plog.read_log(db), info, monitoring.load_reference(), title, artifacts.load_app_baseline())
    banner = ("> **SIMULATED DATA.** Replayed held-out homes" + (" with an invented market change" if a.scenario == "drift" else "")
              + ". Not evidence of real-world performance. The model had seen these homes in training.\n\n")
    out_path = ROOT / f"reports/monitoring_demo_{a.scenario}.md"
    out_path.write_text(text.replace("\n\n", "\n\n" + banner, 1))
    print(out_path.read_text())


if __name__ == "__main__":
    main()
