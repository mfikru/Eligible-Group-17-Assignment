"""REST API for the estimator (FastAPI). Same validation and model as the Streamlit app.

Run:  uvicorn api:app --port 8000      Docs: http://localhost:8000/docs
POST /predict  {"Neighborhood": "NAmes", "GrLivArea": 1500, ...}  ->  estimate, range, drivers, warnings
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Body, FastAPI, HTTPException
from pydantic import BaseModel

import artifacts
import housing as h
import prediction_log as plog

STATE: dict[str, Any] = {}

EXAMPLE = {"Neighborhood": "NAmes", "GrLivArea": 1500, "Stories": 1, "LotArea": 9000, "OverallQual": 6,
           "OverallCond": 5, "YearBuilt": 1975, "YearRemodAdd": 1990, "GarageCars": 2, "TotalBsmtSF": 900,
           "FullBath": 2, "HalfBath": 0, "KitchenQual": "TA"}


@asynccontextmanager
async def lifespan(_: FastAPI):
    STATE["model"], STATE["defaults"], STATE["info"] = artifacts.load_artifacts()
    STATE["version"] = artifacts.model_version()
    STATE["range_err"] = artifacts.range_rmsle(STATE["info"])
    yield
    STATE.clear()


app = FastAPI(
    title="Home Price Estimator API (Ames, Iowa)", version="1.0", lifespan=lifespan,
    description="Prototype. Estimates only, not appraisals. Trained on 2006-2010 Ames sales.",
)


class Outcome(BaseModel):
    request_id: str
    actual_price: float


@app.get("/health")
def health():
    return {"status": "ok", "model_version": STATE["version"]}


@app.get("/model-info")
def model_info():
    info = STATE["info"]
    return {
        "model_version": STATE["version"], "chosen_model": info["chosen_model"],
        "training_rows": info["data_rows_used"], "holdout_rmsle": info["holdout_rmsle"], "form_rmsle": STATE["range_err"],
        "holdout_mae_usd": info["targets_vs_achieved"]["mae_usd"]["holdout"],
        "valuation_year": h.SALE_YEAR, "note": "Estimates only, not appraisals; valid for Ames, Iowa.",
    }


@app.post("/predict")
def predict(inputs: dict[str, Any] = Body(..., examples=[EXAMPLE])):
    t0 = time.perf_counter()
    out = h.safe_estimate(STATE["model"], STATE["defaults"], inputs, STATE["range_err"])
    ms = (time.perf_counter() - t0) * 1000
    rid = plog.log_prediction(inputs, out, source="api", model_version=STATE["version"], latency_ms=ms)
    if not out["ok"]:
        raise HTTPException(status_code=422, detail={"errors": out["errors"], "warnings": out["warnings"],
                                                      "request_id": rid})
    return {"request_id": rid, "model_version": STATE["version"], "warnings": out["warnings"], **out["result"]}


@app.post("/outcome")
def outcome(body: Outcome):
    """Record the real sale price of an earlier estimate so accuracy can be monitored."""
    if not plog.log_outcome(body.request_id, body.actual_price):
        raise HTTPException(status_code=404, detail="Unknown request_id, or the price is not a positive number.")
    return {"status": "recorded"}
