"""How accurate is the app when the user fills in only its 13 fields?

The reported holdout figures (reports/metrics.json) use all 79 recorded features. The app asks for 13 and fills the rest
with neighbourhood-typical values, so it is less accurate. This script measures that gap fairly:
  1. refit the 80% training-split model (same settings as train.py) in memory; the saved model is NOT touched,
  2. build the neighbourhood defaults from the training split only,
  3. score the 292 held-out homes both ways: all features, and through the app's 13-field path.
Needs data/train.csv. Writes reports/app_input_holdout.json, which monitoring.py then uses as its accuracy baseline.

    python evaluate_app_inputs.py [--data data/train.csv]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

import experiments as ex
import housing as h
from simulate_traffic import to_inputs

ROOT = Path(__file__).parent


def _scores(y, p, low=None, high=None) -> dict:
    out = {"mae": float(np.mean(np.abs(p - y))), "rmsle": float(np.sqrt(np.mean((np.log1p(p) - np.log1p(y)) ** 2))),
           "within_15pct": float(np.mean(np.abs(p - y) / y <= 0.15))}
    if low is not None:
        out["range_coverage"] = float(np.mean((y >= low) & (y <= high)))
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(ROOT / "data/train.csv"))
    a = ap.parse_args()
    best = json.loads((ROOT / "models/best_params.json").read_text())
    info = json.loads((ROOT / "reports/metrics.json").read_text())
    h.GBM_PARAMS.update(best["lightgbm"])
    train, test, _ = ex.load_split(a.data)
    model = h.PriceModel(w_linear=float(best["w_linear"])).fit(train, np.log1p(train["SalePrice"].values))
    y = test["SalePrice"].values

    full = _scores(y, np.expm1(model.predict_log(test)))
    defaults = h.compute_defaults(train)  # training split only: no information from the test homes
    rows = [h.safe_estimate(model, defaults, to_inputs(r), info["holdout_rmsle"]) for _, r in test.iterrows()]
    assert all(r["ok"] for r in rows), "some held-out homes were rejected by validation"
    p = np.array([r["result"]["price"] for r in rows])
    app = _scores(y, p)
    app_rmsle = app["rmsle"]
    app["range_coverage_with_full_feature_range"] = float(np.mean(
        (y >= [r["result"]["low"] for r in rows]) & (y <= [r["result"]["high"] for r in rows])))
    app["range_coverage_with_own_range"] = float(np.mean((y >= p * np.exp(-app_rmsle)) & (y <= p * np.exp(app_rmsle))))
    out = {"n_homes": int(len(test)), "all_features": full, "app_13_inputs": app,
           "note": "80%-split model scored on the 292 held-out homes; defaults from the training split only."}
    (ROOT / "reports/app_input_holdout.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
