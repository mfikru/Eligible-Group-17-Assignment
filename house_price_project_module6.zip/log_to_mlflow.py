"""Optional: copy the project's experiment logs into MLflow so runs can be browsed and compared in its UI.

    pip install -r requirements-mlops.txt
    python log_to_mlflow.py            # writes to ./mlflow.db (+ ./mlartifacts)
    mlflow ui --backend-store-uri sqlite:///mlflow.db   # then open http://127.0.0.1:5000

The CSV/JSON logs in reports/ remain the source of truth; this only mirrors them (nothing is re-trained).
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).parent
EXPERIMENT = "ames-house-price"


def main() -> None:
    import mlflow

    mlflow.set_tracking_uri(f"sqlite:///{ROOT / 'mlflow.db'}")
    mlflow.set_experiment(EXPERIMENT)

    cv = pd.read_csv(ROOT / "reports/model_comparison.csv")
    for _, r in cv.iterrows():
        with mlflow.start_run(run_name=r["model"][:80]):
            mlflow.set_tag("stage", "cross-validation")
            mlflow.log_metrics({k: float(r[k]) for k in cv.columns if k != "model" and pd.notna(r[k])})

    best = json.loads((ROOT / "models/best_params.json").read_text())
    info = json.loads((ROOT / "reports/metrics.json").read_text())
    ach = info["targets_vs_achieved"]
    with mlflow.start_run(run_name="FINAL " + info["chosen_model"]):
        mlflow.set_tag("stage", "final holdout (scored once)")
        mlflow.log_params({"w_linear": best["w_linear"], "lasso_alpha": info["lasso_alpha"],
                           **{f"lgbm_{k}": v for k, v in best["lightgbm"].items()}})
        mlflow.log_metrics({"holdout_rmsle": info["holdout_rmsle"], "holdout_mae_usd": ach["mae_usd"]["holdout"],
                            "holdout_r2": ach["r2"]["holdout"], "holdout_within_15pct": ach["within_15pct"]["holdout"],
                            "range_coverage": info["range_coverage"]})
        for f in ("reports/metrics.json", "reports/model_comparison.csv", "reports/tuning_log.csv",
                  "reports/experiment_log.csv", "models/best_params.json"):
            mlflow.log_artifact(str(ROOT / f))
    print(f"Logged {len(cv) + 1} runs to experiment '{EXPERIMENT}' in {ROOT / 'mlflow.db'}")


if __name__ == "__main__":
    main()
