"""Final training and the one-time test-set evaluation (Module 5, Stages 6 to 7).

Order of work
    1. python experiments.py   cross-validation only: compares models, tunes, writes logs and models/best_params.json
    2. python train.py         fits the chosen model on the 80% training split, scores the 20% test split ONCE
                               (together with the two baselines for context), analyses errors, then refits on all
                               cleaned data and saves the model and app files.
    3. python system_tests.py  tests the whole chain, including the app.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import joblib
import matplotlib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder

import housing as h
import monitoring
from experiments import load_split

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).parent
TARGETS = {"rmsle": 0.13, "mae_usd": 16_000, "r2": 0.90, "within_15pct": 0.80, "latency_s": 2.0, "model_mb": 100}


def score(y_usd: np.ndarray, pred_log: np.ndarray) -> dict:
    pred = np.expm1(pred_log)
    return {
        "rmsle": float(np.sqrt(np.mean((pred_log - np.log1p(y_usd)) ** 2))),
        "mae_usd": float(mean_absolute_error(y_usd, pred)),
        "rmse_usd": float(np.sqrt(np.mean((pred - y_usd) ** 2))),
        "r2": float(r2_score(y_usd, pred)),
        "within_15pct": float(np.mean(np.abs(pred - y_usd) / y_usd <= 0.15)),
    }


def main() -> None:
    t0 = time.time()
    best = json.loads((ROOT / "models/best_params.json").read_text())
    h.GBM_PARAMS.update(best["lightgbm"])
    w_linear = float(best["w_linear"])

    train, test, outliers = load_split()
    raw_n = len(train) + len(test) + len(outliers)
    all_clean = pd.concat([train, test], ignore_index=True)
    print(f"{raw_n} rows, {len(outliers)} outliers removed, train {len(train)}, test {len(test)}")
    ytr = np.log1p(train["SalePrice"].values)

    # ---- fit on the training split, score the test split once ------------------------------------------- #
    model = h.PriceModel(w_linear=w_linear).fit(train, ytr)
    med = DummyRegressor(strategy="median").fit(np.zeros((len(train), 1)), ytr)
    simple = make_pipeline(
        ColumnTransformer([("n", "passthrough", ["GrLivArea", "OverallQual"]),
                           ("c", OneHotEncoder(handle_unknown="ignore"), ["Neighborhood"])]),
        LinearRegression()).fit(train, ytr)

    y_test = test["SalePrice"].values
    final = score(y_test, model.predict_log(test))
    base_median = score(y_test, med.predict(np.zeros((len(test), 1))))
    base_simple = score(y_test, simple.predict(test))
    pd.DataFrame([
        {"model": "Baseline A: median price", **base_median},
        {"model": "Baseline B: linear (area, quality, neighbourhood)", **base_simple},
        {"model": "Final: Lasso + LightGBM average", **final},
    ]).to_csv(ROOT / "reports/test_set_results.csv", index=False)
    print("TEST SET (scored once):", json.dumps(final, indent=1))

    # ---- error analysis on the test split ------------------------------------------------------------------ #
    t = test.assign(pred=np.expm1(model.predict_log(test)))
    t["err_pct"] = (t["pred"] - t["SalePrice"]) / t["SalePrice"] * 100
    t["abs_err_pct"] = t["err_pct"].abs()
    t["band"] = pd.qcut(t["SalePrice"], 4, labels=["Q1 cheapest", "Q2", "Q3", "Q4 most expensive"])
    band = t.groupby("band", observed=True).agg(homes=("SalePrice", "size"), median_price=("SalePrice", "median"),
                                                 median_abs_err_pct=("abs_err_pct", "median"), bias_pct=("err_pct", "mean"))
    nb = (t.groupby("Neighborhood").agg(homes=("SalePrice", "size"), median_abs_err_pct=("abs_err_pct", "median"),
                                        bias_pct=("err_pct", "mean"))
          .query("homes >= 8").sort_values("median_abs_err_pct", ascending=False))
    worst = t.sort_values("abs_err_pct", ascending=False).head(8)[
        ["Neighborhood", "GrLivArea", "OverallQual", "OverallCond", "YearBuilt", "SaleCondition", "SalePrice", "pred", "err_pct"]]
    grouped, _ = model.contributions(test)
    importance = (np.expm1(grouped.abs()).mean() * 100).sort_values(ascending=False).head(15)
    importance.rename("mean_abs_effect_pct").to_csv(ROOT / "reports/feature_importance.csv")
    t.to_csv(ROOT / "reports/test_predictions.csv", index=False)
    with open(ROOT / "reports/error_analysis.md", "w") as f:
        f.write("# Error analysis on the test split (scored once)\n\n## By price quartile\n\n" + band.round(1).to_markdown()
                + "\n\n## By neighbourhood (8+ test homes)\n\n" + nb.round(1).to_markdown()
                + "\n\n## Largest errors\n\n" + worst.round(1).to_markdown(index=False)
                + "\n\n## Top drivers (mean absolute effect on price, %)\n\n"
                + importance.round(1).rename("mean_abs_effect_pct").to_markdown() + "\n")

    fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
    ax[0].scatter(t["SalePrice"] / 1e3, t["pred"] / 1e3, s=14, alpha=0.6, color="#2b6cb0")
    lim = [0, max(t["SalePrice"].max(), t["pred"].max()) / 1e3 * 1.05]
    ax[0].plot(lim, lim, "--", color="grey", lw=1)
    ax[0].set(xlabel="Actual price (USD thousands)", ylabel="Predicted (USD thousands)",
              title=f"Test set: predicted vs actual\n(RMSLE {final['rmsle']:.3f}, R² {final['r2']:.2f})")
    ax[1].scatter(t["pred"] / 1e3, t["err_pct"], s=14, alpha=0.6, color="#2b6cb0")
    ax[1].axhline(0, color="grey", lw=1)
    ax[1].axhline(15, color="#c53030", lw=0.8, ls="--")
    ax[1].axhline(-15, color="#c53030", lw=0.8, ls="--")
    ax[1].set(xlabel="Predicted price (USD thousands)", ylabel="Error (% of actual)",
              title="Errors by price level\n(dashed = ±15% target)")
    imp = importance.head(10)[::-1]
    ax[2].barh([h.FRIENDLY.get(i, i) for i in imp.index], imp.values, color="#2b6cb0")
    ax[2].set(xlabel="Mean absolute effect on price (%)", title="Top 10 drivers")
    fig.tight_layout()
    (ROOT / "reports/figures").mkdir(parents=True, exist_ok=True)
    fig.savefig(ROOT / "reports/figures/08_test_results.png", dpi=130, bbox_inches="tight")
    fig.savefig(ROOT / "reports/holdout_results.png", dpi=130, bbox_inches="tight")

    # ---- refit on ALL cleaned data and save ------------------------------------------------------------------ #
    full = h.PriceModel(w_linear=w_linear).fit(all_clean, np.log1p(all_clean["SalePrice"].values))
    defaults = h.compute_defaults(all_clean)
    d = all_clean
    defaults["ranges"] = {
        "GrLivArea": [int(d.GrLivArea.min()), int(d.GrLivArea.max())],
        "LotArea": [int(d.LotArea.min()), int(d.LotArea.quantile(0.99))],
        "TotalBsmtSF": [0, int(d.TotalBsmtSF.max())],
        "YearBuilt": [int(d.YearBuilt.min()), int(d.YearBuilt.max())],
    }
    (ROOT / "models").mkdir(exist_ok=True)
    joblib.dump(full, ROOT / "models/price_model.joblib", compress=3)
    (ROOT / "models/defaults.json").write_text(json.dumps(defaults, indent=1))
    monitoring.write_reference(all_clean, full)  # what the training data looked like, for drift monitoring

    inputs = {"Neighborhood": "NAmes", "GrLivArea": 1500, "Stories": 1, "LotArea": 9000, "OverallQual": 6,
              "OverallCond": 5, "YearBuilt": 1975, "YearRemodAdd": 1990, "GarageCars": 2, "TotalBsmtSF": 900,
              "FullBath": 2, "HalfBath": 0, "KitchenQual": "TA"}
    h.safe_estimate(full, defaults, inputs, final["rmsle"])
    t1 = time.time()
    for _ in range(20):
        h.safe_estimate(full, defaults, inputs, final["rmsle"])
    latency = (time.time() - t1) / 20
    size_mb = (ROOT / "models/price_model.joblib").stat().st_size / 1e6

    ref = all_clean.sample(10, random_state=0)
    (ROOT / "tests/reference_predictions.json").write_text(json.dumps({
        "rows": json.loads(ref.to_json(orient="records")), "predictions": [float(p) for p in full.predict(ref)]}))

    cv = pd.read_csv(ROOT / "reports/model_comparison.csv").set_index("model")
    chosen_cv = float(cv.loc[f"Ensemble: Lasso {w_linear:.1f} + LightGBM {1 - w_linear:.1f}", "cv_rmsle"])
    info = {
        "data_rows_raw": raw_n, "data_rows_used": len(all_clean), "train_rows": len(train), "holdout_rows": len(test),
        "chosen_model": f"Lasso ({w_linear:.1f}) + LightGBM ({1 - w_linear:.1f}) average",
        "holdout_rmsle": final["rmsle"],
        "targets_vs_achieved": {
            "rmsle": {"target": TARGETS["rmsle"], "cv": chosen_cv, "holdout": final["rmsle"]},
            "mae_usd": {"target": TARGETS["mae_usd"], "holdout": final["mae_usd"]},
            "rmse_usd": {"holdout": final["rmse_usd"]},
            "r2": {"target": TARGETS["r2"], "holdout": final["r2"]},
            "within_15pct": {"target": TARGETS["within_15pct"], "holdout": final["within_15pct"]},
            "rmsle_reduction_vs_median_baseline_pct": float((1 - final["rmsle"] / base_median["rmsle"]) * 100),
            "rmsle_reduction_vs_simple_linear_pct": float((1 - final["rmsle"] / base_simple["rmsle"]) * 100),
            "latency_s": {"target": TARGETS["latency_s"], "measured": latency},
            "model_mb": {"target": TARGETS["model_mb"], "measured": size_mb},
        },
        "range_coverage": float(np.mean(np.abs(np.log(t["pred"] / t["SalePrice"])) <= final["rmsle"])),
        "lasso_alpha": float(full.lasso.alpha_), "lasso_nonzero_coefficients": int((full.lasso.coef_ != 0).sum()),
        "n_model_features": len(full.pre.feature_names_), "w_linear": w_linear, "lightgbm_params": best["lightgbm"],
        "seconds_total": time.time() - t0,
    }
    (ROOT / "reports/metrics.json").write_text(json.dumps(info, indent=2, default=str))
    print(json.dumps(info["targets_vs_achieved"], indent=2))


if __name__ == "__main__":
    main()
