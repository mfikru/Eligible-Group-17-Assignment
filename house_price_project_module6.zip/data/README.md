# Data

Download `train.csv` (and `data_description.txt`) from the Kaggle competition
"House Prices: Advanced Regression Techniques" (https://www.kaggle.com/c/house-prices-advanced-regression-techniques)
and place it in this folder as `train.csv`. You must be logged in and accept the competition rules.
The file is not redistributed here.
