"""Model selection experiments (Module 5, Stages 5 and 6).

Everything here uses ONLY the 80% training split and 5-fold cross-validation. The 20% test set is not
loaded for any score in this file; it is used once, in train.py, for the final evaluation.

Writes
    reports/model_comparison.csv   baselines + tuned candidates (CV metrics, train-vs-validation gap)
    reports/tuning_log.csv         every parameter change tried: before, after, result, kept or reverted
    reports/experiment_log.csv     feature / data experiments, including the ones that did not help
    models/best_params.json        settings chosen by cross-validation
"""
from __future__ import annotations

import json
import warnings
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import ElasticNetCV, Lasso, LassoCV, LinearRegression
from sklearn.model_selection import KFold, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

import housing as h

warnings.filterwarnings("ignore")
SEED = 42
ROOT = Path(__file__).parent
MIN_GAIN = 0.0005  # a change is kept only if CV RMSLE improves by more than this


def load_split(data_path: str | None = None):
    """Return (training split, test split, the 2 removed outliers). The test split is only handed on, not scored."""
    raw = pd.read_csv(data_path or ROOT / "data/train.csv")
    clean = h.remove_outliers(raw)
    outliers = raw[~raw["Id"].isin(clean["Id"])]
    train, test = train_test_split(clean, test_size=0.2, random_state=SEED)
    return train.reset_index(drop=True), test.reset_index(drop=True), outliers


def make_folds(train: pd.DataFrame, extra_train: pd.DataFrame | None = None, **pre_kwargs) -> list[dict]:
    """5 folds. Preprocessing is fitted on each fold's training part only (no leakage)."""
    folds = []
    for tr, va in KFold(5, shuffle=True, random_state=SEED).split(train):
        trdf, vadf = train.iloc[tr], train.iloc[va]
        if extra_train is not None:
            trdf = pd.concat([trdf, extra_train], ignore_index=True)
        pre = h.AmesPreprocessor(**pre_kwargs).fit(trdf)
        Xtr, Xva = pre.transform(trdf), pre.transform(vadf)
        sc = StandardScaler().fit(Xtr)
        folds.append(dict(
            tr_df=trdf, va_df=vadf, Xtr=Xtr.values, Xva=Xva.values, Ztr=sc.transform(Xtr), Zva=sc.transform(Xva),
            ytr=np.log1p(trdf["SalePrice"].values), yva=np.log1p(vadf["SalePrice"].values), va_idx=va,
        ))
    return folds


def rmsle(a, b):
    return float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))


def run_cv(folds, fit_predict) -> dict:
    """fit_predict(fold) -> (train_pred_log, val_pred_log). Returns CV stats and out-of-fold predictions."""
    val, trn, n = [], [], sum(len(f["yva"]) for f in folds)
    oof = np.zeros(n)
    for f in folds:
        ptr, pva = fit_predict(f)
        trn.append(rmsle(f["ytr"], ptr))
        val.append(rmsle(f["yva"], pva))
        oof[f["va_idx"]] = pva
    return {"cv_rmsle": float(np.mean(val)), "cv_std": float(np.std(val)), "train_rmsle": float(np.mean(trn)), "oof": oof}


# ---- model fitters ------------------------------------------------------------------------------------------- #
def lasso_fp(alpha=None):
    def fp(f):
        m = (Lasso(alpha=alpha, max_iter=50_000) if alpha else h.make_lasso()).fit(f["Ztr"], f["ytr"])
        return m.predict(f["Ztr"]), m.predict(f["Zva"])
    return fp


def gbm_fp(params):
    def fp(f):
        m = lgb.LGBMRegressor(**params).fit(f["Xtr"], f["ytr"])
        return m.predict(f["Xtr"]), m.predict(f["Xva"])
    return fp


def rf_fp(params):
    def fp(f):
        m = RandomForestRegressor(random_state=SEED, n_jobs=-1, **params).fit(f["Xtr"], f["ytr"])
        return m.predict(f["Xtr"]), m.predict(f["Xva"])
    return fp


def ensemble_fp(lasso_params, w=0.5):
    def fp(f):
        a, b = lasso_fp()(f), gbm_fp(lasso_params)(f)
        return w * a[0] + (1 - w) * b[0], w * a[1] + (1 - w) * b[1]
    return fp


# ---- greedy one-change-at-a-time tuning ------------------------------------------------------------------ #
def greedy_tune(name, start, steps, evaluate, log, passes=2):
    """steps = list of (parameter, [candidate values]). One change at a time, kept only if CV improves.

    Two passes, because the best value of one setting can shift once another has changed.
    Identical configurations are only evaluated once."""
    best = dict(start)
    cache = {json.dumps(best, sort_keys=True, default=str): evaluate(best)["cv_rmsle"]}
    best_score = cache[json.dumps(best, sort_keys=True, default=str)]
    log.append(dict(model=name, parameter="(starting point)", before="", after=json.dumps(best, default=str),
                    cv_rmsle_before=np.nan, cv_rmsle_after=best_score, kept=True,
                    reason="Starting settings (close to library defaults)"))
    for p in range(passes):
        for param, values in steps:
            before_val = best[param]
            for v in values:
                cand = {**best, param: v}
                key = json.dumps(cand, sort_keys=True, default=str)
                if v == best[param] or key in cache:
                    continue
                cache[key] = evaluate(cand)["cv_rmsle"]
                score = cache[key]
                kept = score < best_score - MIN_GAIN
                log.append(dict(model=name, parameter=param, before=before_val, after=v, cv_rmsle_before=best_score,
                                cv_rmsle_after=score, kept=kept,
                                reason=f"Pass {p + 1}: " + ("improved CV RMSLE by more than 0.0005, kept" if kept
                                                            else "no clear gain, reverted")))
                if kept:
                    best, best_score = cand, score
                    before_val = v
    return best, best_score


def main() -> None:
    train, _test, outliers = load_split()  # the test split is deliberately never used below
    print(f"Training split: {len(train)} homes (test split is not touched in this script)")
    folds = make_folds(train)
    tuning, exp = [], []

    # ---- baselines ------------------------------------------------------------------------------------ #
    def median_fp(f):
        m = DummyRegressor(strategy="median").fit(np.zeros((len(f["ytr"]), 1)), f["ytr"])
        return m.predict(np.zeros((len(f["ytr"]), 1))), m.predict(np.zeros((len(f["yva"]), 1)))

    def simple_fp(f):
        pipe = make_pipeline(
            ColumnTransformer([("n", "passthrough", ["GrLivArea", "OverallQual"]),
                               ("c", OneHotEncoder(handle_unknown="ignore"), ["Neighborhood"])]),
            LinearRegression()).fit(f["tr_df"], f["ytr"])
        return pipe.predict(f["tr_df"]), pipe.predict(f["va_df"])

    results = {
        "Baseline A: always predict the median price": run_cv(folds, median_fp),
        "Baseline B: linear regression (area, quality, neighbourhood)": run_cv(folds, simple_fp),
    }

    print("baselines done", flush=True)
    # ---- tuning: Lasso ---------------------------------------------------------------------------------- #
    lasso_cv = run_cv(folds, lasso_fp())
    for a in [0.0003, 0.001, 0.003, 0.01, 0.03]:
        r = run_cv(folds, lasso_fp(a))
        tuning.append(dict(model="Lasso", parameter="alpha (penalty strength)", before="", after=a,
                           cv_rmsle_before=np.nan, cv_rmsle_after=r["cv_rmsle"], kept=False,
                           reason="Fixed-value scan for reference"))
    tuning.append(dict(model="Lasso", parameter="alpha (penalty strength)", before="scan above",
                       after="chosen by internal 5-fold CV inside each training fold",
                       cv_rmsle_before=np.nan, cv_rmsle_after=lasso_cv["cv_rmsle"], kept=True,
                       reason="Automatic alpha search matches or beats the best fixed value"))

    print("lasso done", flush=True)
    # ---- tuning: LightGBM -------------------------------------------------------------------------------- #
    gbm_start = dict(n_estimators=300, learning_rate=0.1, num_leaves=31, min_child_samples=20, subsample=1.0,
                     subsample_freq=0, colsample_bytree=1.0, reg_lambda=0.0, random_state=SEED, verbose=-1, n_jobs=1)
    gbm_steps = [
        ("learning_rate", [0.05, 0.02]), ("n_estimators", [600, 1000, 1500]),
        ("num_leaves", [16, 8, 4]), ("colsample_bytree", [0.6, 0.4, 0.25]),
        ("subsample", [0.7]), ("min_child_samples", [10, 5]), ("reg_lambda", [1.0, 5.0]),
    ]

    def ev_gbm(p):
        q = dict(p)
        if q["subsample"] < 1.0:
            q["subsample_freq"] = 1
        return run_cv(folds, gbm_fp(q))

    gbm_best, _ = greedy_tune("LightGBM", gbm_start, gbm_steps, ev_gbm, tuning)
    if gbm_best["subsample"] < 1.0:
        gbm_best["subsample_freq"] = 1

    print("lightgbm tuned", gbm_best, flush=True)
    # ---- tuning: Random Forest ----------------------------------------------------------------------------- #
    rf_start = dict(n_estimators=300, max_features=1.0, min_samples_leaf=1, max_depth=None)
    rf_steps = [("max_features", [0.6, 0.4, 0.25]), ("min_samples_leaf", [2, 3, 5]), ("max_depth", [20, 12])]
    rf_best, _ = greedy_tune("Random Forest", rf_start, rf_steps, lambda p: run_cv(folds, rf_fp(p)), tuning)

    print("rf tuned", rf_best, flush=True)
    # ---- tuned candidates + ensemble ----------------------------------------------------------------------- #
    results["Model 1: Lasso regression"] = lasso_cv
    results["Model 2: Random Forest (tuned)"] = run_cv(folds, rf_fp(rf_best))
    results["Model 3: LightGBM (tuned)"] = run_cv(folds, gbm_fp(gbm_best))
    for w in [0.3, 0.5, 0.7]:
        r = run_cv(folds, ensemble_fp(gbm_best, w))
        tuning.append(dict(model="Ensemble", parameter="weight on Lasso", before="", after=w, cv_rmsle_before=np.nan,
                           cv_rmsle_after=r["cv_rmsle"], kept=False, reason="Weight scan"))
        results[f"Ensemble: Lasso {w:.1f} + LightGBM {1 - w:.1f}"] = r
    ens_names = [k for k in results if k.startswith("Ensemble")]
    best_ens = min(ens_names, key=lambda k: results[k]["cv_rmsle"])
    w_best = float(best_ens.split("Lasso ")[1].split(" ")[0])
    # Keep the proposal's equal-weight average unless another weight is clearly better.
    w_final = 0.5 if results["Ensemble: Lasso 0.5 + LightGBM 0.5"]["cv_rmsle"] - results[best_ens]["cv_rmsle"] <= MIN_GAIN else w_best
    for t in tuning:
        if t["model"] == "Ensemble":
            t["kept"] = abs(t["after"] - w_final) < 1e-9

    print("candidates done", flush=True)
    # ---- feature / data experiments (reference = Lasso + LightGBM average, equal weights) ------------------- #
    ref = results["Ensemble: Lasso 0.5 + LightGBM 0.5"]["cv_rmsle"]

    def experiment(name, change, folds_, fp, decision_rule="gain", note=""):
        r = run_cv(folds_, fp)
        diff = r["cv_rmsle"] - ref
        exp.append(dict(experiment=name, change=change, cv_rmsle=r["cv_rmsle"], difference_vs_reference=diff,
                        outcome="Better" if diff < -MIN_GAIN else ("Worse" if diff > MIN_GAIN else "No real change"),
                        note=note))
        return r

    ens_fp = ensemble_fp(gbm_best)
    experiment("Reference", "Final setup: outliers removed, engineered features, log-skew fix, Lasso + LightGBM", folds, ens_fp)
    experiment("Keep the 2 outliers in training", "Add the two huge low-price homes back into every training fold "
               "(validation rows unchanged)", make_folds(train, extra_train=outliers), ens_fp)
    experiment("No log transform of skewed features", "skew_threshold = infinity",
               make_folds(train, skew_threshold=np.inf), ens_fp)
    experiment("Remove engineered totals", "Drop TotalSF, TotalBath, TotalPorch and the Has-feature flags",
               make_folds(train, drop_features=("TotalSF", "TotalBath", "TotalPorch", "HasPool", "Has2ndFloor",
                                                "HasGarage", "HasBasement", "HasFireplace")), ens_fp)
    experiment("Add sale type and sale condition", "Keep SaleType and SaleCondition as inputs",
               make_folds(train, keep_columns=("SaleType", "SaleCondition")), ens_fp,
               note="Rejected whatever the score: these are only known once a sale happens, so using them would leak.")

    def lasso_raw_price(f):  # same Lasso, but trained on the price itself instead of log price
        m = h.make_lasso().fit(f["Ztr"], np.expm1(f["ytr"]))
        p = lambda Z: np.log1p(np.clip(m.predict(Z), 1, None))
        return p(f["Ztr"]), p(f["Zva"])

    r_log = lasso_cv["cv_rmsle"]
    r_raw = run_cv(folds, lasso_raw_price)
    exp.append(dict(experiment="Train on price instead of log price (Lasso only)",
                    change="Target = SalePrice, predictions clipped at 1", cv_rmsle=r_raw["cv_rmsle"],
                    difference_vs_reference=r_raw["cv_rmsle"] - r_log,
                    outcome="Worse" if r_raw["cv_rmsle"] - r_log > MIN_GAIN else "No real change",
                    note="Compared with Lasso on log price, not with the ensemble."))

    def enet_fp(f):
        m = ElasticNetCV(l1_ratio=[0.5, 0.9], alphas=np.logspace(-4, -1, 20), cv=5, max_iter=50_000,
                         random_state=SEED).fit(f["Ztr"], f["ytr"])
        return m.predict(f["Ztr"]), m.predict(f["Zva"])

    r_en = run_cv(folds, enet_fp)
    exp.append(dict(experiment="ElasticNet instead of Lasso", change="Mix of L1 and L2 penalty",
                    cv_rmsle=r_en["cv_rmsle"], difference_vs_reference=r_en["cv_rmsle"] - r_log,
                    outcome="Better" if r_en["cv_rmsle"] - r_log < -MIN_GAIN else (
                        "Worse" if r_en["cv_rmsle"] - r_log > MIN_GAIN else "No real change"),
                    note="Compared with Lasso alone. More complexity, no gain."))

    # ---- final comparison table (USD metrics from out-of-fold predictions) -------------------------------- #
    y_usd = np.concatenate([np.expm1(f["yva"]) for f in sorted(folds, key=lambda f: f["va_idx"][0])])
    order = np.argsort(np.concatenate([f["va_idx"] for f in folds]))
    y_oof_usd = np.expm1(np.concatenate([f["yva"] for f in folds]))[order]
    rows = []
    for name, r in results.items():
        p = np.expm1(r["oof"])
        rows.append(dict(
            model=name, cv_rmsle=r["cv_rmsle"], cv_rmsle_sd=r["cv_std"], train_rmsle=r["train_rmsle"],
            gap_val_minus_train=r["cv_rmsle"] - r["train_rmsle"],
            cv_mae_usd=float(np.mean(np.abs(p - y_oof_usd))), cv_rmse_usd=float(np.sqrt(np.mean((p - y_oof_usd) ** 2))),
            cv_r2=float(1 - np.sum((p - y_oof_usd) ** 2) / np.sum((y_oof_usd - y_oof_usd.mean()) ** 2)),
        ))
    comp = pd.DataFrame(rows)
    comp.to_csv(ROOT / "reports/model_comparison.csv", index=False)
    pd.DataFrame(tuning).to_csv(ROOT / "reports/tuning_log.csv", index=False)
    pd.DataFrame(exp).to_csv(ROOT / "reports/experiment_log.csv", index=False)
    best = {"lightgbm": gbm_best, "random_forest": rf_best, "w_linear": w_final,
            "lasso_alpha_note": "chosen by internal CV (LassoCV)"}
    (ROOT / "models/best_params.json").write_text(json.dumps(best, indent=1, default=str))
    pd.set_option("display.width", 250)
    print(comp.round(4).to_string(index=False))
    print(pd.DataFrame(exp).round(4).to_string(index=False))
    print("LightGBM best:", gbm_best)
    print("RF best:", rf_best, "| ensemble weight on Lasso:", w_final)


if __name__ == "__main__":
    main()
