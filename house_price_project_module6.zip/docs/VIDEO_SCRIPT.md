# Capstone Video Script (max 10 minutes, max 250 MB)

Target 9:30 so there is margin. One member per segment (nine members; the wrap-up is shared). Say clearly what is **implemented**, what is **simulated**, and what is **future work**. Rehearse with a timer.

| Time | Speaker | Segment | Say and show |
| --- | --- | --- | --- |
| 0:00–0:50 | Miftah | Problem and solution | Manual appraisals are slow and subjective. Module 4 proposal, Module 5 model, Module 6: app, API, monitoring. Real Kaggle Ames data; the only simulated data are the monitoring demo traffic. |
| 0:50–2:10 | Meron | App demo | Typical North Ames home, 1,500 sq ft, quality 6: **$154,259**, range $134,098 to $177,451 (about ±14%). Move quality to 9: the estimate rises. Type living area 50: error message, no crash. Show the "record real sale price" box and the privacy note. |
| 2:10–3:10 | Tenalem | API | Open `/docs`. Send the example request, show `price`, `drivers`, `request_id`. Send `GrLivArea: 50`: 422 with a message. |
| 3:10–4:10 | Ekram | Data, model, experiment tracking | Lasso + LightGBM, 205 features, CV table. Holdout (all features): RMSLE 0.111, MAE $13,236, 87% within 15%. Show the CSV logs and the MLflow UI (9 runs). |
| 4:10–5:00 | Hailemariam | Testing | 59 unit/API tests and 39 system tests pass; CI workflow. Story: the API exposed a validation gap (a number accepted as a neighbourhood); fixed and tested. |
| 5:00–5:50 | Mezemir | Accuracy monitoring | Prediction log; actual sale prices attached. Key finding: through the 13-field form, MAE $17,555 and 78% within 15% (not 87%), so the range became ±14% and monitoring uses the form's baseline. |
| 5:50–6:40 | Nebiyu | Drift monitoring | Show `monitoring_demo_drift.md`. **Say "simulated" out loud.** Six measures (five inputs and the predicted price) drifted significantly, MAE $54,492, 9 alerts; the normal replay raises none. PSI thresholds 0.10 and 0.25. |
| 6:40–7:30 | Mihret | Responsible AI | Fairness audit: 0 of 18 judged groups flagged; OldTown closest (11.0%); IDOTRR and Blmngtn on the watch list (too few homes). No personal data stored. Not for lending decisions. |
| 7:30–8:20 | Fami | Deployment | GitHub, Streamlit hosting, `docker compose up --build` (app :8501, API :8000, shared log). State plainly what you verified and what remains. |
| 8:20–9:30 | Everyone (Miftah leads) | Reflection | Limitations: 2010 values, Ames only, form accuracy, small audit, monitoring run by hand. Future work: retrain on recent sales, scheduled alerts, API security. Each member adds one sentence on their contribution or lesson. |

**Recording tips:** zoom the browser to 125% so text is readable; keep audio clear; compress to 720p if the file is near 250 MB; have a backup recording of the demos in case a live demo fails.
