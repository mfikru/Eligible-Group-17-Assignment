# Simulated Data Statement (Deliverable D)

**The model is trained and evaluated on real, non-simulated data. One part of the project uses simulated traffic, and it is labelled as such.**

## Real data (training and evaluation)
- **Source:** the Ames Housing training file from the Kaggle competition *House Prices: Advanced Regression Techniques* (https://www.kaggle.com/c/house-prices-advanced-regression-techniques), compiled by Dean De Cock (2011) from Ames, Iowa Assessor's Office records: 1,460 residential sales (2006 to 2010), 79 features, target `SalePrice`.
- **Use:** two extreme outliers removed (1,458 homes). 1,166 homes (80%) for cross-validated model selection; 292 (20%) held out and scored once.
- **Privacy:** property characteristics only; no names, addresses or other personal information.
- **Redistribution:** the Kaggle file is not redistributed. Users download it themselves.
- **Limits:** results describe Ames sales from 2006 to 2010 only, not a live market, another city or production.

## Simulated data (monitoring demonstration only)
- **What:** `simulate_traffic.py` generates requests for the monitoring demo, because a prototype has no real users. Scenario `normal` replays the 292 held-out homes (real features and real sale prices) as if they were users. Scenario `drift` is invented: living area ×1.25, quality +1, homes built 5 to 25 years later, new-build neighbourhoods over-sampled, and sale prices ×1.40.
- **Why:** to show that the drift, accuracy and alert logic reacts when conditions change.
- **Where it goes:** a separate demo database (`logs/demo_*.db`) and the reports `reports/monitoring_demo_*.md`, each stamped "SIMULATED DATA". It never enters the real log, the model, or any reported accuracy figure.
- **Not evidence of performance:** the saved model was refitted on all homes, so it has seen the replayed homes.

## Also stated
- The unit and system tests use hand-written example inputs (for instance "Living area = 50"); they are test cases, not datasets.

> **Before submitting, confirm** that the `train.csv` you trained on is the original Kaggle download. If you used any modified or regenerated copy, say exactly what was changed and why.
