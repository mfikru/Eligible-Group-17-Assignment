# Monitoring, Support and Maintenance Plan

The tooling below is **implemented in the prototype**; running it on a schedule, alert delivery and acting on alerts are the parts that remain a plan. Thresholds are starting points, not tuned values.

## 1. Performance monitoring (implemented: `monitoring.py`, `prediction_log.py`)
Every request is logged. When the real sale price is known it is attached through the app's "record the real sale price" box or `POST /outcome`. `python monitoring.py report` compares the logged results with the **form's own held-out baseline** (`reports/app_input_holdout.json`), not with the full-feature holdout, because the form is less accurate.

| What | Baseline | Alert when |
| --- | --- | --- |
| MAE | $17,555 | more than 20% higher (above about $21,100) |
| Within 15% of actual | 78% | more than 10 points lower (below 68%) |
| Typical-range coverage | 76% | more than 10 points lower (below 66%) |
| 95th-percentile response time | about 0.2 s in the demo | above 2 s |
| Reliability | | rejection or warning share rising over time |

Reports need at least 20 estimates with known prices (accuracy) or 30 valid requests (drift); below that they say "not enough data" because small samples are noisy.

## 2. Data drift (implemented)
`models/reference_stats.json` stores what the training homes looked like (bins for living area, lot, basement, year built, quality, garage; neighbourhood mix; predicted-price distribution). The report computes the Population Stability Index for each: below 0.10 stable, 0.10 to 0.25 moderate, above 0.25 significant (alert). Housing markets shift with prices, interest rates and new development, so drift is the main retraining trigger.

## 3. Error handling (implemented, review process planned)
- Invalid input is rejected with a message naming the field (app and API 422). Unusual input gets an estimate plus a warning. `safe_estimate` never raises, and logging failures never break a request.
- Planned: review rejected requests, warnings and exceptions weekly; a rising share means a UI problem, a client bug or drift.
- Direction tests (`system_tests.py`) and `tests/reference_predictions.json` catch unintended model changes after any update.

## 4. Data and model updates (planned)
1. The data end in 2010, so retrain on recent local sales before any real use.
2. Retrain quarterly or when an alert fires: `python experiments.py` → `python train.py` (also rewrites the drift reference) → `python evaluate_app_inputs.py`.
3. Compare the candidate with the current model on the same held-out homes (RMSLE, MAE, within 15%, form baseline) and run all tests; promote only if it is better.
4. Version the model: `models/price_model.joblib` carries a 12-character fingerprint shown in `/health` and stored with every prediction, so each estimate can be traced to its model. Keep the previous model for rollback. MLflow (`log_to_mlflow.py`) records each training run.
5. Keep excluding `SaleType` and `SaleCondition` (known only after a sale: leakage).

## 5. Security and responsible AI
- **Privacy:** the log stores only the form values, estimate, warnings, model version and timing. No names, addresses or IP addresses (checked by a unit test). `PRICE_LOG=0` turns logging off, and the app tells users it is on.
- **Secrets:** none in the repo; use environment variables or Streamlit secrets if added. `data/train.csv` stays out of GitHub.
- **Fairness (implemented: `fairness_audit.py`):** error and bias by neighbourhood and price band on the held-out homes. Result: none of 18 judged groups flagged; OldTown is closest (11.0%); IDOTRR (+17%, 7 homes) and Blmngtn (−10%, 4 homes) are too small to judge. Neighbourhood can stand in for protected characteristics, so repeat the audit on larger, recent data and do not use the model as the sole basis for lending or pricing decisions.
- **Transparency:** every output shows the range, main drivers and an "estimate, not an appraisal" notice; values are as of 2010 until retrained.
- **API hardening (planned):** authentication, rate limiting, request-size limits, HTTPS, pinned and updated dependencies.

## 6. Support and maintenance (planned)
- **Defects and requests:** GitHub Issues with inputs, expected and actual output, app version and screenshot.
- **Fixing:** reproduce with a failing test, fix, run `python -m pytest tests -q` and `python system_tests.py` (the CI workflow runs both on every push), then merge.
- **Dependencies:** review monthly. Upgrade scikit-learn, LightGBM and pandas together, because the saved model must load with the versions it was trained with; retrain and re-test after any upgrade.
- **Changelog:** `CHANGELOG.md` records every model, data and dependency change.
- **Roadmap:** scheduled monitoring and alerts, retraining on recent sales, larger fairness audit, richer inputs to close the gap to the full-feature model.

## 7. Evidence that the monitoring works (SIMULATED traffic)
`reports/monitoring_demo_normal.md`: 200 replayed held-out homes, no alerts. `reports/monitoring_demo_drift.md`: an invented market shift raises 9 alerts. This shows the tooling reacts correctly; it says nothing about real-world performance.
