# Submission Checklist
**Verify yourselves (the author of these files could not):**
- [ ] `docker compose up --build` works; screenshot the app on :8501 and `/docs` on :8000
- [ ] Public Streamlit link opens in a private browser window; paste it into the README
- [ ] GitHub repo is accessible to reviewers; CI (`tests` workflow) passes on GitHub; paste the repo link into the README
- [ ] `pip install -r requirements-api.txt` then `python -m pytest tests -q` and `python system_tests.py` pass on a team member's own computer

**Content**
- [ ] README: links filled in, group responsibilities match what each person did (`docs/TEAM_WORKSTREAMS.md`)
- [ ] Screenshots in `screenshots/`: valid estimate, error message, API `/docs`, passing tests, monitoring report, MLflow UI, fairness audit
- [ ] Confirmed `train.csv` is the original Kaggle download (data statement)
- [ ] Did not commit `data/train.csv` or `reports/train.csv`. `reports/test_predictions.csv` and `reports/feature_importance.csv` hold Kaggle-derived rows: check the competition rules and your instructor's guidance, or remove them from the public repo (the fairness audit and two tests need `test_predictions.csv`)
- [ ] No keys, passwords or credentials anywhere; `logs/`, `mlflow.db`, `mlartifacts/` not committed (already in `.gitignore`)
- [ ] Check the course's AI-use policy; if it requires disclosure, state that an AI assistant helped with the Module 6 code additions and drafting

**Canvas**
- [ ] A: portfolio (ZIP or GitHub link plus app link)
- [ ] B: video, at most 10 minutes and 250 MB, every member speaks
- [ ] C: one-page retrospective (`docs/RETROSPECTIVE.md`; convert to Word or PDF if needed)
- [ ] D: simulated data statement (`docs/SIMULATED_DATA_STATEMENT.md`)
