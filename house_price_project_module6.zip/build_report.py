"""Builds Module5_Implementation_Report.ipynb (and an HTML copy) from the saved results.

Usage:  python build_report.py
Needs: reports/*.csv|json produced by experiments.py, train.py and system_tests.py, and data/train.csv.
Numbers quoted in the text are read from those files at build time, so text and tables cannot disagree.
"""
from __future__ import annotations

import json
from pathlib import Path

import nbformat as nbf
import numpy as np
import pandas as pd
from nbclient import NotebookClient
from nbconvert import HTMLExporter

import housing as h

ROOT = Path(__file__).parent
R = ROOT / "reports"
raw = pd.read_csv(ROOT / "data/train.csv")
df = h.remove_outliers(raw)

m = json.loads((R / "metrics.json").read_text())
a = m["targets_vs_achieved"]
comp = pd.read_csv(R / "model_comparison.csv").set_index("model")
tune = pd.read_csv(R / "tuning_log.csv")
exp = pd.read_csv(R / "experiment_log.csv").set_index("experiment")
test = pd.read_csv(R / "test_set_results.csv").set_index("model")
pred = pd.read_csv(R / "test_predictions.csv")
sysrows = pd.read_csv(R / "system_tests.csv")
final = test.loc["Final: Lasso + LightGBM average"]
bA, bB = test.iloc[0], test.iloc[1]
cvA, cvB = comp.iloc[0], comp.iloc[1]
lasso, rf, gbm = comp.loc["Model 1: Lasso regression"], comp.loc["Model 2: Random Forest (tuned)"], comp.loc["Model 3: LightGBM (tuned)"]
ens = comp.loc["Ensemble: Lasso 0.5 + LightGBM 0.5"]
gbm_start = tune[(tune.model == "LightGBM") & (tune.parameter == "(starting point)")].cv_rmsle_after.iloc[0]
log_err = np.abs(np.log(pred["pred"] / pred["SalePrice"]))
coverage = float((log_err <= final["rmsle"]).mean())
nonnormal_all = float((df.SaleCondition != "Normal").mean())
worst8 = pred.reindex(pred["abs_err_pct"].sort_values(ascending=False).index).head(8)
nonnormal_worst = int((worst8.SaleCondition != "Normal").sum())
band = pred.assign(b=pd.qcut(pred.SalePrice, 4, labels=["Q1", "Q2", "Q3", "Q4"])).groupby("b", observed=True).err_pct.mean()
n_pass = int((sysrows.result == "Pass").sum())
usd = lambda x: f"${x:,.0f}"  # noqa: E731

cells = []
md = lambda t: cells.append(nbf.v4.new_markdown_cell(t.strip()))  # noqa: E731
code = lambda t: cells.append(nbf.v4.new_code_cell(t.strip()))  # noqa: E731

# --------------------------------------------------------------------------------------------------------------- #
md(f"""
# Predicting House Sale Prices
## FUSE-AI-201: AI Development and Implementation
### Module 5: AI Project Implementation report

Real Estate domain · Regression · Ames Housing data (Kaggle: House Prices, Advanced Regression Techniques)

| | |
| --- | --- |
| Project title | Predicting House Sale Prices: a fair-market-value estimator for residential real estate |
| Group number | Group 17 |
| Group members | Meron Mengesha, Tenalem Temesgen Mesele, Nebiyu, Arega Mulu Mezemir, Birku Getie Mihret, Fikru Minwalkulet, Hailemariam Moges, Ekram Yimam Mohammed, Fami Abdi Mohammed, and Miftah Abdella Mohammed |
| Course | FUSE-AI-201: AI Development and Implementation |
| Submission date | 20 October 2026 |

This report continues the approved Module 4 proposal. **Rule #1 check:** the project, data and goal are the same.
The changes made during implementation are listed in section 4.

### Summary at a glance

| | |
| --- | --- |
| Problem | Home valuation is slow, subjective and inconsistent |
| Solution | A regression model plus a web app that returns a price estimate, a typical-error range and the top 5 drivers |
| Data | Ames Housing: 1,460 sales, 79 features, Ames, Iowa, 2006 to 2010 |
| Final model | Equal average of a Lasso regression and a LightGBM model |
| Test-set result (scored once) | RMSLE {final.rmsle:.3f}, MAE {usd(final.mae_usd)}, R² {final.r2:.3f}, {final.within_15pct * 100:.0f}% of homes within 15% of the actual price |
| Targets from the proposal | All met |
| Testing | {n_pass} of {len(sysrows)} whole-system test cases pass |
| Main limits | One city and period; cheap older homes and abnormal sales are the weakest areas; the price range is approximate |
""")

code("""
import json, sys, warnings
from pathlib import Path
import numpy as np, pandas as pd
from IPython.display import display, Markdown, Image
warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path.cwd()))
import housing as h, eda

def show(d, index=False):
    display(Markdown(d.to_markdown(index=index)))

def img(name):
    display(Image(str(eda.FIG / name)))

raw = pd.read_csv("data/train.csv")
df = h.remove_outliers(raw)
R = Path("reports")
""")

# 2 ------------------------------------------------------------------------------------------------------------ #
md(f"""
## 2. Problem statement

**Problem.** Home valuation is slow, subjective and inconsistent. Sellers must choose a listing price, buyers must judge whether an
asking price is fair, and agents and lenders need a defensible reference value. Today this relies on agent judgement and comparable
sales, paid appraisals that take days, and public automated valuation tools that are usually black boxes.

**Who is affected, and why it matters.** Overpriced homes sit unsold; underpriced homes lose the seller money; buyers risk overpaying;
lenders face risk when valuations disagree.

**How AI can help.** Price depends on many interacting features (size, quality, location, age). A model trained on past sales can
learn those relationships and give a fast, consistent estimate, and it can show which features drive the number.

**Is AI appropriate here?** Yes, with a check. A rule such as "price per square foot by neighbourhood" is the obvious alternative.
Baseline B below (linear regression on area, quality and neighbourhood) is a close stand-in for that rule: it reaches RMSLE
{bB.rmsle:.3f} on the test set, while the final model reaches {final.rmsle:.3f}, an error {a['rmsle_reduction_vs_simple_linear_pct']:.0f}% lower. The data
has 1,460 labelled sales and 79 features, enough for a learnable pattern, and a simple rule alone leaves a clear gap.

### Success criteria (set in the proposal, unchanged)

| Criterion | Target / expected result |
| --- | --- |
| Model performance | RMSLE 0.13 or lower; MAE under $16,000; R² at least 0.90 |
| Prediction / output | At least 80% of test homes within 15% of the actual price; the output shows a price, a range and the top 5 drivers |
| User input | Missing, non-numeric, negative, out-of-range and unknown-category inputs are rejected or warned with a clear message |
| System functionality | The app returns an estimate for any valid input and updates when an input changes |
| Testing | Normal, missing, invalid, unexpected-category and extreme inputs all behave as expected; each estimate returns in under 2 seconds |
""")

# 3 ------------------------------------------------------------------------------------------------------------ #
md("""
## 3. Target users

| User | How they use the system |
| --- | --- |
| Primary: home sellers and real estate agents | Enter about 13 facts about a home to get a starting price and see what drives it; change an input to test "what if" ideas |
| Secondary: home buyers | Check whether an asking price looks reasonable and why |
| Secondary: lenders and appraisers | Use the estimate as a screening reference to decide which valuations need a full review (not for lending decisions) |
""")

# 4 ------------------------------------------------------------------------------------------------------------ #
md(f"""
## 4. Proposed AI solution

**Task: regression.** The output is a number (a price), so this is regression, not classification. The model predicts
`log(1 + SalePrice)` and the result is converted back to dollars. The log is used because prices are right-skewed (section 7) and because
the Kaggle metric, RMSLE, treats a 10% error on a cheap house the same as a 10% error on an expensive one.

### Inputs the app asks for

| Input | Type | Description |
| --- | --- | --- |
| Neighbourhood | Category (25 areas) | Area of Ames |
| Living area | Number, sq ft | Above-ground living area |
| Stories | 1 or 2 | Used to split the area into floors |
| Lot size | Number, sq ft | Land area |
| Basement area | Number, sq ft | 0 if none |
| Overall quality | Whole number 1 to 10 | Materials and finish |
| Overall condition | Whole number 1 to 10 (optional) | Current state of repair |
| Year built, year remodelled | Whole numbers | Converted to ages as of 2010 |
| Garage capacity | Whole number 0 to 6 | Cars |
| Full and half bathrooms | Whole numbers | Counted together as total bathrooms |
| Kitchen quality | Category Ex, Gd, TA, Fa, Po | Quality of the kitchen |

All other fields (roof, heating, fireplaces and so on) are filled with the typical value for the chosen neighbourhood, and the app labels
those drivers as assumed.

### Features and target

| Variable group | Feature or target? | Data type | Purpose |
| --- | --- | --- | --- |
| Living area, basement, floors, lot size; engineered TotalSF | Feature | Numeric | Size is the strongest price signal |
| OverallQual, OverallCond, KitchenQual, ExterQual, BsmtQual and similar | Feature | Ordinal (1 to 5 or 1 to 10) | Build quality and condition |
| HouseAge, RemodAge, Remodeled | Feature (engineered) | Numeric / flag | Replace year columns; age lowers price |
| Neighborhood and other location fields | Feature | Category, one-hot | Location effect |
| Garage, bathrooms, porch, fireplaces, pool flags | Feature | Numeric / flag | Amenities |
| SalePrice | **Target** | Numeric (USD), modelled as log(1 + price) | What the system predicts |
| SaleType, SaleCondition, MoSold, YrSold | Not used | | Only known once a sale happens, so using them would leak |

### Workflow and architecture
""")

code("""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(13, 2.2)); ax.axis("off")
steps = ["User", "Web app\\n(Streamlit)", "Input\\nvalidation", "Preprocessing\\n(features, encoding)",
         "Lasso +\\nLightGBM", "Price, range,\\ntop drivers", "Result\\nshown"]
for i, s in enumerate(steps):
    x = i * 1.9
    ax.text(x, 0.5, s, ha="center", va="center", fontsize=9,
            bbox=dict(boxstyle="round,pad=0.5", fc="#ebf4ff", ec="#2b6cb0"))
    if i < len(steps) - 1:
        ax.annotate("", xy=(x + 1.2, 0.5), xytext=(x + 0.7, 0.5), arrowprops=dict(arrowstyle="->", color="#2b6cb0"))
ax.set_xlim(-0.8, 12.2); ax.set_ylim(0, 1)
eda.FIG.mkdir(parents=True, exist_ok=True)
fig.savefig(eda.FIG / "00_architecture.png", dpi=130, bbox_inches="tight")
img("00_architecture.png")
""")

md(f"""
### Changes from the Module 4 proposal

| Item | Proposal | What happened and why |
| --- | --- | --- |
| Problem, data, task, users | Ames Housing, regression, sellers and agents | Unchanged |
| Success targets | RMSLE 0.13 or lower, MAE under $16,000, R² at least 0.90, 80% within 15% | Unchanged |
| App inputs | About 10 fields | 13 fields. Overall condition was added because it was a top-5 driver in early tests |
| Input validation | Mentioned in the architecture | Implemented as its own layer with per-field rules (section 12) |
| Explanations | SHAP | Lasso contributions are exact; LightGBM contributions use its built-in TreeSHAP; blended with the same weights as the prediction |
| Fallback model | Random Forest or Ridge | Random Forest was tested and not chosen (section 9) |
| Sale type and condition | Reviewed for leakage | Excluded; a test showed they would add almost nothing anyway |
| Data source | Kaggle | Results were produced with a copy that has Kaggle's shape (1,460 rows, 81 columns). **Re-run on your own Kaggle download before presenting.** |
""")

# 5 ------------------------------------------------------------------------------------------------------------ #
md(f"""
## 5. Dataset

| Item | Information |
| --- | --- |
| Dataset name | Ames Housing dataset, as used in the Kaggle competition "House Prices: Advanced Regression Techniques" |
| Source and access | Compiled by Dean De Cock (Journal of Statistics Education, 2011); downloaded from Kaggle (login and rules acceptance required) |
| Records / variables | 1,460 training rows; 79 explanatory variables plus Id and SalePrice |
| Target variable | SalePrice, final sale price in US dollars |
| Format | CSV with a text data dictionary |
| Coverage | Home sales in Ames, Iowa, 2006 to 2010 |
| Licence / usage | Free for education under the competition rules; contains no personal identifiers; cite the source |

### Inspection
""")

code("""
print("shape:", raw.shape)
print("duplicate rows:", raw.duplicated().sum(), "| duplicate Ids:", raw.Id.duplicated().sum())
print("columns with missing values:", (raw.isna().sum() > 0).sum(), "of", raw.shape[1])
print("target skewness: raw %.2f, after log1p %.2f" % (raw.SalePrice.skew(), np.log1p(raw.SalePrice).skew()))
print("target is numeric, so there is no class imbalance to handle")
show(eda.variable_overview(raw).head(12))
print("... (all 81 columns are profiled by eda.variable_overview)")
""")

md("### Data-quality log")
code("show(eda.quality_log(raw))")

# 6 ------------------------------------------------------------------------------------------------------------ #
md(f"""
## 6. Data preparation

### Preprocessing record

| Step | Action | Reason |
| --- | --- | --- |
| Missing values | NA that means "feature absent" becomes "None" (categories) or 0 (sizes); LotFrontage uses the neighbourhood median; one Electrical value uses the mode | Deleting rows would remove most of the data, and the data dictionary defines these NAs. Medians and modes are learned from training rows only |
| Duplicates | Checked: 0 found. Count stays at 1,460 | Nothing to remove |
| Inconsistent data | Exterior2nd spellings standardised to Exterior1st (105 homes) | Same material was written two ways |
| Encoding | Quality columns as ordered numbers (None=0 to Excellent=5); other categories one-hot; categories with under 3 training homes ignored; MSSubClass converted to a category | Ordered scales keep their order; unordered categories should not imply an order |
| Scaling | Standardised for the Lasso only; not used for LightGBM | Penalised linear models need comparable scales; tree models do not |
| Skewed features | log1p applied to {len(h.AmesPreprocessor().fit(df).log_cols_)} skewed numeric features | Reduces the pull of extreme values on the linear model. The experiment log shows this made no measurable difference here |
| Outliers | 2 homes over 4,000 sq ft sold under $300,000 removed (1,460 to 1,458) | Documented partial sales; keeping them made CV worse (section 9) |
| Feature engineering | TotalSF, TotalBath, TotalPorch, HouseAge, RemodAge, Remodeled, has-pool/garage/basement/fireplace/second-floor flags | Combine related columns; removing them made CV worse (section 9) |
| Data split | 80% training ({m['train_rows']:,} homes) and 20% test ({m['holdout_rows']} homes), random_state 42; 5-fold cross-validation inside the training part | Test set is used once, at the end. Stratifying is not needed for a numeric target |
| Leakage control | Imputers, encoders and scalers are re-fitted inside every cross-validation fold; sale type, condition and month are not used | Prevents information from validation or future data leaking into training |
""")

# 7 ------------------------------------------------------------------------------------------------------------ #
md("## 7. Exploratory data analysis")
md("### Descriptive statistics")
code("show(eda.descriptive_table(df), index=True)")
md(f"""
**Reading the table.** The mean price ({usd(df.SalePrice.mean())}) is above the median ({usd(df.SalePrice.median())}) and the skewness is
{df.SalePrice.skew():.2f}, so a few expensive homes pull the average up. Lot area is far more extreme: its skewness is
{df.LotArea.skew():.1f} and the largest lot ({int(df.LotArea.max()):,} sq ft) is {df.LotArea.max() / df.LotArea.median():.0f} times the median. These are reasons for a log
transform. Overall quality has mean {df.OverallQual.mean():.1f} and standard deviation {df.OverallQual.std():.1f}, so most homes sit at roughly 5 to 7 and the
extremes (1, 2, 10) have few examples.
""")

md("### Question 1: is the target skewed?")
code("eda.fig_target(df); img('01_target_distribution.png')")
md(f"""
**Interpretation.** Price is right-skewed (skew {df.SalePrice.skew():.2f}); after log(1 + price) it is close to symmetric (skew {np.log1p(df.SalePrice).skew():.2f}).
**Impact on modelling:** train on the log price. A later experiment confirms it: a Lasso trained on raw price scored RMSLE
{exp.loc['Train on price instead of log price (Lasso only)', 'cv_rmsle']:.3f} against {lasso.cv_rmsle:.3f} on the log price.
""")

md("### Question 2: where is data missing, and is it really missing?")
code("eda.fig_missing(raw); img('02_missing_values.png')")
md("""
**Interpretation.** Most of the missing values are not gaps. PoolQC (99.5%), MiscFeature, Alley, Fence, FireplaceQu and the garage and
basement fields are NA because the house has no pool, alley, fence and so on. Only LotFrontage (17.7%), one Electrical value and
8 veneer values are real gaps. **Impact on modelling:** fill the first group with "None" or 0 and impute only the real gaps; dropping
rows or columns here would discard useful information.
""")

md("### Question 3: are there extreme homes that do not follow the pattern?")
code("eda.fig_outliers(raw); img('03_area_vs_price_outliers.png')")
md(f"""
**Interpretation.** Two homes of 4,676 and 5,642 sq ft sold for $184,750 and $160,000, far below what their size suggests. They are the
documented partial sales. **Impact on modelling:** remove them. Keeping them in training raised CV RMSLE by
{exp.loc['Keep the 2 outliers in training', 'difference_vs_reference']:+.4f}.
""")

md("### Question 4: how strongly do quality, location and age relate to price?")
code("eda.fig_quality(df); img('04_quality_vs_price.png'); eda.fig_neighborhood(df); img('05_neighbourhood_prices.png'); eda.fig_age(df); img('07_age_vs_price.png')")
g = df.groupby("Neighborhood").SalePrice.median().sort_values()
q = df.groupby("OverallQual").SalePrice.median()
md(f"""
**Interpretation.**
- **Quality:** median price rises with every step of overall quality, from {usd(q.loc[1])} at quality 1 to {usd(q.loc[10])} at quality 10, and the spread
  within a level also grows in dollar terms at the top, so errors in dollars will tend to be larger for high-end homes.
- **Location:** the median price ranges from {usd(g.iloc[0])} (Meadow Village) to {usd(g.iloc[-1])} (Northridge Heights), about {g.iloc[-1] / g.iloc[0]:.1f} times higher. Some
  neighbourhoods have very few homes (Blueste has {int(df.Neighborhood.value_counts().min())}), so estimates there are less certain.
- **Age:** newer homes sell for more (correlation of age with log price {np.corrcoef(h.SALE_YEAR - df.YearBuilt, np.log1p(df.SalePrice))[0, 1]:.2f}).
  Among homes 40 to 90 years old, remodelled and never-remodelled homes have almost the same median price (about $135,000 each) and the same median quality, so the data does not show a
  clear remodelling premium.
""")
md("Median price for some simple groups (these are raw comparisons and overlap with quality and age, so they are not cause and effect):")
code("show(eda.group_comparison(df))")

md("### Question 5: which features track price, and which overlap with each other?")
code("eda.fig_correlation(df); img('06_correlations.png')")
md("""
**Interpretation.** Overall quality (0.82), total floor area (0.82) and living area (0.74) have the strongest correlation with log price.
Several features overlap heavily: garage capacity and garage area (0.89), and total floor area with living area (0.86).
**Impact on modelling:** correlated features make plain linear coefficients unstable, which is a reason to use a penalised model (Lasso,
which tends to keep one of a correlated pair) alongside tree models, which are not affected.
""")

md("### Findings, evidence and impact")
md(f"""
| Finding | Evidence | Possible impact on modelling |
| --- | --- | --- |
| Price is right-skewed | Skew {df.SalePrice.skew():.2f}, {np.log1p(df.SalePrice).skew():.2f} after log | Model log price; report RMSLE |
| Most NAs mean "none" | PoolQC 99.5%, Alley 94%, Fence 81% NA | Fill with "None", do not delete |
| Two partial-sale outliers | 4,676 and 5,642 sq ft homes under $185,000 | Remove before training |
| Quality and size dominate | Correlation 0.82 with log price | Expect them to be top drivers |
| Location matters | Median $88,000 to $315,000 across neighbourhoods | Keep Neighborhood; warn for tiny areas |
| Overlapping features | Garage cars and area correlate at 0.89 | Use a penalised linear model and trees |
| Small neighbourhoods | Blueste has 2 homes | Expect weaker accuracy there |

**EDA summary.** Price is driven mainly by quality, size and location, with age as a further effect. The main quality problems were
mislabelled "missing" values, two outliers, a spelling mismatch and a skewed target; all were fixed. While modelling, watch for
correlated features, small neighbourhoods and leakage from sale-related columns.
""")

# 8 ------------------------------------------------------------------------------------------------------------ #
md(f"""
## 8. Baseline model

**Why these baselines.** Baseline A always predicts the training median price. It is the trivial reference: any useful model must beat it.
Baseline B is linear regression on living area, overall quality and neighbourhood, the three things a person would use for a
rule-of-thumb valuation. It is easy to explain and fast. Its limits: it cannot capture interactions or the many other features.

All scores below use 5-fold cross-validation on the training split only; the test set is not touched until section 11.

| Model | CV RMSLE | CV MAE | CV RMSE | CV R² | Notes |
| --- | --- | --- | --- | --- | --- |
| Baseline A: median price | {cvA.cv_rmsle:.3f} | {usd(cvA.cv_mae_usd)} | {usd(cvA.cv_rmse_usd)} | {cvA.cv_r2:.3f} | Negative R²: no better than predicting the average |
| Baseline B: linear (area, quality, neighbourhood) | {cvB.cv_rmsle:.3f} | {usd(cvB.cv_mae_usd)} | {usd(cvB.cv_rmse_usd)} | {cvB.cv_r2:.3f} | Already explains most of the variation from three inputs |

**Interpretation.** Three inputs already give R² {cvB.cv_r2:.2f}, so the problem has a strong learnable pattern, and a simple model is a hard
baseline to beat: the typical error is {cvB.cv_rmsle * 100:.0f}% of the price.
""")

# 9 ------------------------------------------------------------------------------------------------------------ #
md("## 9. Model improvement")
md(f"""
Three candidate models were compared with the same data, folds and metrics: a Lasso regression (a linear model that suits the many
overlapping features), a Random Forest (the proposal's fallback) and LightGBM (gradient boosting, which captures interactions), plus an
average of Lasso and LightGBM because the two make different kinds of error.

### Model comparison (5-fold cross-validation, training split)
""")
code("""
c = pd.read_csv(R / "model_comparison.csv")
c = c.rename(columns={"cv_rmsle": "CV RMSLE", "cv_rmsle_sd": "CV sd", "train_rmsle": "Train RMSLE",
                      "gap_val_minus_train": "Gap (CV minus train)", "cv_mae_usd": "CV MAE $", "cv_rmse_usd": "CV RMSE $", "cv_r2": "CV R²"})
show(c.round({"CV RMSLE": 4, "CV sd": 4, "Train RMSLE": 4, "Gap (CV minus train)": 4, "CV MAE $": 0, "CV RMSE $": 0, "CV R²": 3}))
""")
md(f"""
### Overfitting check

| Model | Train RMSLE | CV RMSLE | What it shows |
| --- | --- | --- | --- |
| Lasso | {lasso.train_rmsle:.3f} | {lasso.cv_rmsle:.3f} | Small gap ({lasso.gap_val_minus_train:.3f}); the penalty keeps it honest |
| Random Forest | {rf.train_rmsle:.3f} | {rf.cv_rmsle:.3f} | Large gap ({rf.gap_val_minus_train:.3f}): it memorises the training homes, so it is also the weakest candidate |
| LightGBM | {gbm.train_rmsle:.3f} | {gbm.cv_rmsle:.3f} | Large gap ({gbm.gap_val_minus_train:.3f}): fits training data far better than new data |
| Lasso + LightGBM average | {ens.train_rmsle:.3f} | {ens.cv_rmsle:.3f} | Gap {ens.gap_val_minus_train:.3f}, between the two |

The tree models fit the training data about three times as tightly (in RMSLE) as new data. That is a warning, not a failure, because their
validation scores are still good, but it is the reason for blending in the steadier Lasso.

### Tuning log

Settings were changed one at a time on cross-validation only. A change was kept only if CV RMSLE improved by more than 0.0005, and the search
made two passes because the best value of one setting can shift after another changes. Only the changes that were kept are shown below;
every attempt is in `reports/tuning_log.csv`.
""")
code("""
t = pd.read_csv(R / "tuning_log.csv")
kept = t[(t.kept) & (t.parameter != "(starting point)")][["model", "parameter", "before", "after", "cv_rmsle_after", "reason"]]
kept = kept.rename(columns={"cv_rmsle_after": "CV RMSLE after"})
show(kept.round(4))
print(len(t), "settings tried in total;", int(t.kept.sum()), "kept (including starting points and the final choices).")
""")
md(f"""
**What the tuning showed.** LightGBM improved from {gbm_start:.3f} with near-default settings to {gbm.cv_rmsle:.3f}. The largest gains came from fewer leaves per tree, using only 40% of features per tree, and more trees at a lower learning
rate; the first two limit overfitting. Random Forest improved only
from {tune[(tune.model == 'Random Forest') & (tune.parameter == '(starting point)')].cv_rmsle_after.iloc[0]:.3f} to {rf.cv_rmsle:.3f} and stayed behind. The Lasso
penalty was chosen by internal cross-validation. Weights of 0.5 and 0.7 on the Lasso scored almost identically ({comp.loc['Ensemble: Lasso 0.5 + LightGBM 0.5', 'cv_rmsle']:.4f} and
{comp.loc['Ensemble: Lasso 0.7 + LightGBM 0.3', 'cv_rmsle']:.4f}), so the proposal's equal average was kept.

### Experiment log, including what did not help
""")
code("""
e = pd.read_csv(R / "experiment_log.csv")
e = e.rename(columns={"cv_rmsle": "CV RMSLE", "difference_vs_reference": "Difference"})
show(e[["experiment", "change", "CV RMSLE", "Difference", "outcome", "note"]].round(4).fillna(""))
""")
md(f"""
**Lessons.**
- **Keeping the outliers** made validation worse by {exp.loc['Keep the 2 outliers in training', 'difference_vs_reference']:.4f}: two bad rows are enough to hurt.
- **Removing the engineered totals** made it worse by {exp.loc['Remove engineered totals', 'difference_vs_reference']:.4f}, so the features earn their place.
- **Log-transforming skewed features** made no measurable difference with this model mix; it is kept because it is harmless and
  protects the linear model.
- **Training on raw price** was far worse ({exp.loc['Train on price instead of log price (Lasso only)', 'cv_rmsle']:.3f}), so the log target matters.
- **ElasticNet** added complexity for no gain over Lasso.
- **Sale type and condition** changed the score by {exp.loc['Add sale type and sale condition', 'difference_vs_reference']:+.4f}, which is within noise. They were rejected because they
  are only known once a sale happens.

### Final-model decision

| Consideration | Lasso alone | Lasso + LightGBM average |
| --- | --- | --- |
| CV RMSLE | {lasso.cv_rmsle:.4f} | {ens.cv_rmsle:.4f} |
| CV MAE | {usd(lasso.cv_mae_usd)} | {usd(ens.cv_mae_usd)} |
| Fold-to-fold spread (sd of RMSLE) | {lasso.cv_rmsle_sd:.4f} | {ens.cv_rmsle_sd:.4f} |
| Explainability | Exact contributions | Exact (Lasso) blended with TreeSHAP (LightGBM) |
| Size and speed | Tiny, fast | {a['model_mb']['measured']:.2f} MB, {a['latency_s']['measured']:.2f} s per estimate |

**Selected: the equal-weight average of Lasso and LightGBM.** The CV gain over the Lasso alone is real but small
({lasso.cv_rmsle - ens.cv_rmsle:.4f}, about a third of the fold-to-fold spread), and it also lowers the average dollar error by
{usd(lasso.cv_mae_usd - ens.cv_mae_usd)}. It stays small, quick and explainable, and it is the design the proposal committed to. If the group needed the
simplest possible model, the Lasso alone would be a defensible choice.
""")

# 10 ----------------------------------------------------------------------------------------------------------- #
md(f"""
## 10. Final model

- **Model:** average of a Lasso regression ({m['lasso_nonzero_coefficients']} of {m['n_model_features']} features kept) and a LightGBM model, both predicting log price.
- **LightGBM settings:** 600 trees, learning rate 0.02, 16 leaves, at least 5 homes per leaf, 70% of rows and 40% of features per tree.
- **Features:** {m['n_model_features']} after cleaning, engineering and encoding.
- **Training data:** the final model used for the app is re-fitted on all 1,458 cleaned homes. The scores in section 11 come from the version fitted on the training split only.
- **Explanations:** for each estimate, the contribution of each original variable is the Lasso coefficient times the standardised value, blended
  with LightGBM's TreeSHAP values using the same weights as the prediction. They add up exactly to the prediction (checked by a test).
  The app shows the effect as a percentage compared with an average home.
- **Files:** `models/price_model.joblib` and `models/defaults.json`.
""")

# 11 ----------------------------------------------------------------------------------------------------------- #
md(f"""
## 11. Evaluation

The final model was scored **once** on the {m['holdout_rows']} test homes that were never used for any choice. The two baselines were scored on the same homes for context.

| Metric | Result | Target | What it means for this project |
| --- | --- | --- | --- |
| RMSLE | {final.rmsle:.3f} (CV {a['rmsle']['cv']:.3f}) | 0.13 or lower | A typical estimate is about {final.rmsle * 100:.0f}% away from the actual price. Test and CV agree, which suggests no overfitting to the training split |
| MAE | {usd(final.mae_usd)} | under $16,000 | On average the estimate is off by this many dollars; about {final.mae_usd / df.SalePrice.median() * 100:.0f}% of the median price |
| RMSE | {usd(final.rmse_usd)} | none set | Higher than MAE, so some homes have much larger errors (see below) |
| R² | {final.r2:.3f} | at least 0.90 | The model explains about {final.r2 * 100:.0f}% of the variation in prices in this sample |
| Homes within 15% | {final.within_15pct * 100:.1f}% | at least 80% | About {int(round(final.within_15pct * 8))} in 8 estimates are within 15% of the actual price |
| Better than median baseline | {a['rmsle_reduction_vs_median_baseline_pct']:.0f}% lower RMSLE ({bA.rmsle:.3f} to {final.rmsle:.3f}) | at least 30% | Clear improvement over guessing the median |
| Better than simple linear baseline | {a['rmsle_reduction_vs_simple_linear_pct']:.0f}% lower RMSLE ({bB.rmsle:.3f} to {final.rmsle:.3f}) | at least 10% | Worth more than a three-input rule |

Every target was met on this test sample. These are results on one sample of 292 homes from one city, so they show the model works within
the limits of this dataset, not that it will work everywhere.
""")
code("img('08_test_results.png')")
md(f"""
### Error analysis

**By price level.** The cheapest quarter of homes is over-estimated on average (bias {band.loc['Q1']:+.1f}%), and the most expensive quarter is
under-estimated ({band.loc['Q4']:+.1f}%). The model pulls extreme prices toward the middle, which is typical of regression.

**By neighbourhood.** Old Town has the largest typical error (11% median absolute error on 23 test homes, with +6% bias). Old Town and
Iowa DOT and Rail Road are among the lowest-priced neighbourhoods (section 7), where a given dollar error is a larger share of the price.

**Largest errors.** The 8 biggest misses are listed below. {nonnormal_worst} of 8 were sales flagged as not "Normal" (abnormal sales such as foreclosures or family
sales, or allocated sales), compared with {nonnormal_all * 100:.0f}% of all homes. Sale condition is not available to the model by design, so such homes
are priced below what their features suggest and the model over-estimates them. This is a limit of the data and the use case, not
something more tuning would fix.
""")
code("""
p = pd.read_csv(R / "test_predictions.csv")
w = p.reindex(p.abs_err_pct.sort_values(ascending=False).index).head(8)[
    ["Neighborhood", "GrLivArea", "OverallQual", "OverallCond", "YearBuilt", "SaleCondition", "SalePrice", "pred", "err_pct"]]
show(w.round(1))
""")
md(f"""
**How reliable is the price range?** The app shows the estimate plus or minus {final.rmsle * 100:.0f}% as a "typical range". On the test homes, {coverage * 100:.0f}% fell inside that
range. A one-standard-deviation band would cover about two thirds if errors were evenly spread; coverage is higher here because a few very large errors inflate the RMSLE. The label "typical range" is fair, but it is **not** a guarantee: roughly one in four homes
fell outside it.
""")

# 12 ----------------------------------------------------------------------------------------------------------- #
md(f"""
## 12. Testing the complete solution

The whole chain was tested: input, validation, preprocessing, model, prediction, output, including the real Streamlit app run headlessly.
**{n_pass} of {len(sysrows)} test cases passed.** The same checks run on demand with `python system_tests.py`; 19 further unit tests run
with `python -m pytest tests`.

Validation rules: required fields; numbers only (a thousands comma is accepted); finite values; whole numbers where needed; hard limits
(for example living area 200 to 10,000 sq ft, quality 1 to 10, year built 1800 to 2010); allowed kitchen codes; neighbourhood matched without
regard to case or spaces; warnings for values outside the range the model learned from, unknown neighbourhoods and remodel dates before build dates.
""")
code("""
s = pd.read_csv(R / "system_tests.csv")
s = s.rename(columns={"group": "Group", "test_case": "Test case", "input": "Input", "expected": "Expected", "actual": "Actual", "result": "Pass / Fail"})
show(s)
print(s["Pass / Fail"].value_counts().to_string())
""")

# 13 ----------------------------------------------------------------------------------------------------------- #
md("""
## 13. Working prototype

Run it with `streamlit run app.py`, or, without installing anything locally, open `Colab_Run_Project.ipynb` in Google Colab, which includes a form for trying the estimator. The user fills in the form on the left and the estimate, range and top drivers update as soon as any
input changes. If an input is invalid, an error message names the field and no estimate is shown. Three example estimates from the same
code the app uses:
""")
code("""
import joblib
model = joblib.load("models/price_model.joblib")
defaults = json.loads(Path("models/defaults.json").read_text())
rmsle = json.loads((R / "metrics.json").read_text())["holdout_rmsle"]
base = {"Neighborhood": "NAmes", "GrLivArea": 1500, "Stories": 1, "LotArea": 9000, "OverallQual": 6, "OverallCond": 5,
        "YearBuilt": 1975, "YearRemodAdd": 1990, "GarageCars": 2, "TotalBsmtSF": 900, "FullBath": 2, "HalfBath": 0, "KitchenQual": "TA"}
examples = {
    "Typical North Ames home": {},
    "High-end Northridge Heights home": dict(Neighborhood="NridgHt", Stories=2, GrLivArea=2600, OverallQual=9, YearBuilt=2005,
                                              YearRemodAdd=2005, KitchenQual="Gd", HalfBath=1, GarageCars=3),
    "Small older Old Town home": dict(Neighborhood="OldTown", GrLivArea=900, OverallQual=4, YearBuilt=1925, YearRemodAdd=1950,
                                       GarageCars=0, TotalBsmtSF=600, FullBath=1),
}
for name, change in examples.items():
    o = h.safe_estimate(model, defaults, {**base, **change}, rmsle)
    r = o["result"]
    print(f"{name}: ${r['price']:,.0f}  (range ${r['low']:,.0f} to ${r['high']:,.0f})")
    for d in r["drivers"]:
        print(f"    {d['label']:<22}{d['effect_pct']:+6.1f}%  ({'from your inputs' if d['from_user'] else 'assumed'})")
""")

# 14 ----------------------------------------------------------------------------------------------------------- #
md(f"""
## 14. Limitations and responsible-use notes

- **One city, one period.** Ames, 2006 to 2010. Homes are valued as of 2010, and prices have changed since. The model should not be used for other cities.
- **Not an appraisal.** The app says so. It should not be used for lending, tax or legal decisions.
- **Uncertainty.** The typical range covered {coverage * 100:.0f}% of test homes, so about one in four fell outside it.
- **Weaker areas.** Cheap, older homes are over-estimated on average; small neighbourhoods have little data; abnormal sales are not recognised.
- **Assumed fields.** Anything the user does not enter is set to the neighbourhood's typical value, so unusual homes (for example a very old roof) are not captured.
- **Fairness.** The data has no protected attributes, but neighbourhood affects price and could reflect historical inequality. Neighbourhood has a modest average effect
  (about 1.6% of price) compared with quality and size, and errors are reported by neighbourhood. The estimate should support a human conversation, not replace one.
- **Privacy and security.** The data contains no owner names. The app stores nothing the user enters, and inputs are validated before use.
- **How the test set was handled.** An earlier prototype of this project printed test-set scores for all candidate models before the final workflow was
  fixed. No choice was based on them, and the current workflow selects everything with cross-validation and scores the test set once, but the test sample
  is therefore a little less pristine than a brand-new one.
- **Data copy.** Results were produced with a copy of the data matching Kaggle's file shape. Re-run the pipeline on your own Kaggle download and check that the numbers agree.
""")

# 15-17 -------------------------------------------------------------------------------------------------------- #
md("""
## 15. Future improvements

| Improvement | Limitation it addresses |
| --- | --- |
| Add recent data from more cities and adjust for market trends | One city and an old period |
| Comparable-sales finder | Users cannot see which past sales support the estimate |
| Calibrated prediction intervals (for example quantile models) | The plus or minus range is approximate: about one test home in four fell outside it |
| A flag for likely distressed or abnormal sales | These cause the largest errors |
| Photos or listing text as extra inputs | Condition details are not in the fields |
| Scheduled retraining and monitoring | The model ages as markets move |
""")

md(f"""
## 16. Conclusion

The group implemented the approved proposal end to end: a regression model that predicts Ames house prices with a typical error of about
{final.rmsle * 100:.0f}% (RMSLE {final.rmsle:.3f}, MAE {usd(final.mae_usd)}, R² {final.r2:.2f}), a web app that explains each estimate, an input-validation layer, and {n_pass} passing system tests.
It beat both baselines clearly and met every target from the proposal on a test sample scored once. The main limits are a single
city and period, over-estimation of cheap older homes and abnormal sales, and a price range that missed about one home in four on the test sample.
The next step, Module 6, is deployment and validation of the running system.
""")

md("""
## 17. Team contributions

**Group 17**

| No. | Member |
| --- | --- |
| 1 | Meron Mengesha |
| 2 | Tenalem Temesgen Mesele |
| 3 | Nebiyu |
| 4 | Arega Mulu Mezemir |
| 5 | Birku Getie Mihret |
| 6 | Fikru Minwalkulet |
| 7 | Hailemariam Moges |
| 8 | Ekram Yimam Mohammed |
| 9 | Fami Abdi Mohammed |
| 10 | Miftah Abdella Mohammed |
""")

# --------------------------------------------------------------------------------------------------------------- #
nb = nbf.v4.new_notebook(cells=cells)
nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
NotebookClient(nb, timeout=240, resources={"metadata": {"path": str(ROOT)}}).execute()
out = ROOT / "Module5_Implementation_Report.ipynb"
nbf.write(nb, out)
html, _ = HTMLExporter(exclude_input=True).from_notebook_node(nb)
(ROOT / "Module5_Implementation_Report.html").write_text(html)
print("wrote", out.name, "and HTML,", len(cells), "cells")
