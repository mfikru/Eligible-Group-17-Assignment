"""Monitoring tools: operations, data drift (PSI) and accuracy against real sale prices.

    python monitoring.py build-reference --data data/train.csv   # one-off (train.py also does it): models/reference_stats.json
    python monitoring.py report [--db logs/predictions.db] [--out reports/monitoring_report.md]

Thresholds come from docs/MONITORING_SUPPORT_MAINTENANCE_PLAN.md. They are starting points, not tuned values.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

import prediction_log as plog

ROOT = Path(__file__).parent
REFERENCE_PATH = ROOT / "models/reference_stats.json"

NUM_FEATURES = ["GrLivArea", "LotArea", "TotalBsmtSF", "YearBuilt", "OverallQual", "GarageCars"]
PSI_MODERATE, PSI_SIGNIFICANT = 0.10, 0.25           # common rule of thumb
MIN_DRIFT_ROWS, MIN_OUTCOMES = 30, 20                 # below this the numbers are too noisy to act on
MAE_ALERT_FACTOR, WITHIN15_DROP, COVERAGE_DROP = 1.20, 0.10, 0.10  # drops are in absolute share points
LATENCY_ALERT_S = 2.0
EPS = 1e-4


# --------------------------------------------------------------------------- #
# Reference (what the training data looked like)
# --------------------------------------------------------------------------- #
def _edges(values: np.ndarray, n_bins: int = 10) -> list[float]:
    qs = np.unique(np.quantile(values, np.linspace(0, 1, n_bins + 1)[1:-1]))
    return [float(q) for q in qs]


def _props(values, edges) -> list[float]:
    idx = np.digitize(np.asarray(values, dtype=float), edges)
    counts = np.bincount(idx, minlength=len(edges) + 1)
    return (counts / max(counts.sum(), 1)).tolist()


def build_reference(df: pd.DataFrame, model=None) -> dict:
    """Summarise the training data (cleaned, raw columns) so incoming requests can be compared with it."""
    ref = {"n": int(len(df)), "numeric": {}, "neighborhood": {}, "prediction": None}
    for c in NUM_FEATURES:
        e = _edges(df[c].astype(float).values)
        ref["numeric"][c] = {"edges": e, "props": _props(df[c], e)}
    ref["neighborhood"] = (df["Neighborhood"].value_counts(normalize=True)).to_dict()
    if model is not None:
        p = np.asarray(model.predict(df), dtype=float)
        e = _edges(p)
        ref["prediction"] = {"edges": e, "props": _props(p, e),
                             "note": "predictions on the training homes (in-sample)"}
    return ref


def write_reference(df: pd.DataFrame, model=None, path: Path = REFERENCE_PATH) -> None:
    path.write_text(json.dumps(build_reference(df, model), indent=1))


def load_reference(path: Path = REFERENCE_PATH) -> dict | None:
    return json.loads(path.read_text()) if path.exists() else None


# --------------------------------------------------------------------------- #
# Drift
# --------------------------------------------------------------------------- #
def psi(expected: list[float], actual: list[float]) -> float:
    """Population Stability Index between two proportion vectors of the same length."""
    e = np.clip(np.asarray(expected, dtype=float), EPS, None)
    a = np.clip(np.asarray(actual, dtype=float), EPS, None)
    return float(np.sum((a - e) * np.log(a / e)))


def psi_status(v: float) -> str:
    return "significant" if v >= PSI_SIGNIFICANT else "moderate" if v >= PSI_MODERATE else "stable"


def drift_report(log: pd.DataFrame, ref: dict) -> dict:
    ok = log[log["ok"] == 1] if len(log) else log
    if len(ok) < MIN_DRIFT_ROWS:
        return {"enough_data": False, "n": int(len(ok)), "features": {}}
    feats = {}
    for c, r in ref["numeric"].items():
        if c in ok:
            v = psi(r["props"], _props(ok[c].astype(float), r["edges"]))
            feats[c] = {"psi": v, "status": psi_status(v)}
    cats = list(ref["neighborhood"])
    cur = ok["Neighborhood"].map(lambda x: x if x in ref["neighborhood"] else "(unseen)").value_counts(normalize=True)
    v = psi([ref["neighborhood"][k] for k in cats] + [0.0], [float(cur.get(k, 0.0)) for k in cats + ["(unseen)"]])
    feats["Neighborhood"] = {"psi": v, "status": psi_status(v)}
    if ref.get("prediction") and ok["price"].notna().any():
        p = ref["prediction"]
        v = psi(p["props"], _props(ok["price"].dropna(), p["edges"]))
        feats["Predicted price"] = {"psi": v, "status": psi_status(v)}
    return {"enough_data": True, "n": int(len(ok)), "features": feats}


# --------------------------------------------------------------------------- #
# Operations and accuracy
# --------------------------------------------------------------------------- #
def operations_report(log: pd.DataFrame) -> dict:
    if log.empty:
        return {"requests": 0}
    warn = log["warnings"].map(lambda s: len(json.loads(s)) > 0)
    lat = log["latency_ms"].dropna()
    return {
        "requests": int(len(log)),
        "rejected_share": float((log["ok"] == 0).mean()),
        "warning_share": float(warn[log["ok"] == 1].mean()) if (log["ok"] == 1).any() else 0.0,
        "latency_median_ms": float(lat.median()) if len(lat) else None,
        "latency_p95_ms": float(lat.quantile(0.95)) if len(lat) else None,
        "by_source": log["source"].value_counts().to_dict(),
        "model_versions": log["model_version"].value_counts().to_dict(),
    }


def baseline_from(info: dict, app: dict | None) -> dict:
    """What 'normal' accuracy looks like. The app's 13-field form is the thing being monitored, so use its own held-out
    accuracy (python evaluate_app_inputs.py); fall back to the full-feature holdout if that has not been measured."""
    if app:
        return {"mae": app["mae"], "rmsle": app["rmsle"], "within_15pct": app["within_15pct"],
                "range_coverage": app["range_coverage_with_own_range"], "source": "13-field form on held-out homes"}
    ach = info["targets_vs_achieved"]
    return {"mae": ach["mae_usd"]["holdout"], "rmsle": info["holdout_rmsle"], "within_15pct": ach["within_15pct"]["holdout"],
            "range_coverage": info.get("range_coverage"), "source": "all-feature holdout (the form is less accurate)"}


def performance_report(log: pd.DataFrame, base: dict) -> dict:
    done = log[(log["ok"] == 1) & log["actual_price"].notna()] if len(log) else log
    if len(done) < MIN_OUTCOMES:
        return {"enough_data": False, "n": int(len(done))}
    act, pred = done["actual_price"].astype(float), done["price"].astype(float)
    err = (pred - act) / act
    m = {
        "mae": float((pred - act).abs().mean()),
        "rmsle": float(np.sqrt(np.mean((np.log1p(pred) - np.log1p(act)) ** 2))),
        "within_15pct": float((err.abs() <= 0.15).mean()),
        "range_coverage": float(((act >= done["low"]) & (act <= done["high"])).mean()),
        "median_bias_pct": float(err.median() * 100),
    }
    alerts = []
    if m["mae"] > MAE_ALERT_FACTOR * base["mae"]:
        alerts.append(f"MAE ${m['mae']:,.0f} is more than {round((MAE_ALERT_FACTOR - 1) * 100)}% above the baseline ${base['mae']:,.0f}.")
    if m["within_15pct"] < base["within_15pct"] - WITHIN15_DROP:
        alerts.append(f"Only {m['within_15pct']:.0%} of estimates are within 15% of the actual price "
                      f"(baseline {base['within_15pct']:.0%}, alert below {base['within_15pct'] - WITHIN15_DROP:.0%}).")
    if base.get("range_coverage") and m["range_coverage"] < base["range_coverage"] - COVERAGE_DROP:
        alerts.append(f"The typical range holds only {m['range_coverage']:.0%} of actual prices "
                      f"(baseline {base['range_coverage']:.0%}): recalibrate it.")
    return {"enough_data": True, "n": int(len(done)), "metrics": m, "baseline": base, "alerts": alerts}


def make_report(log: pd.DataFrame, info: dict, ref: dict | None, title: str = "Monitoring report", app: dict | None = None) -> tuple[str, list[str]]:
    ops, perf = operations_report(log), performance_report(log, baseline_from(info, app))
    drift = drift_report(log, ref) if ref else {"enough_data": False, "n": 0, "features": {}}
    alerts: list[str] = []
    L = [f"# {title}", ""]

    L += ["## Operations", ""]
    if ops["requests"] == 0:
        L += ["No requests logged yet.", ""]
    else:
        L += [f"- Requests: **{ops['requests']}** ({ops['rejected_share']:.0%} rejected as invalid, "
              f"{ops['warning_share']:.0%} of accepted ones carried a warning)",
              f"- Sources: {ops['by_source']}; model versions: {ops['model_versions']}"]
        if ops["latency_median_ms"] is not None:
            L.append(f"- Response time: median {ops['latency_median_ms']:.0f} ms, 95th percentile {ops['latency_p95_ms']:.0f} ms")
            if ops["latency_p95_ms"] / 1000 > LATENCY_ALERT_S:
                alerts.append(f"95th-percentile response time exceeds {LATENCY_ALERT_S:.0f} s.")
        L.append("")

    L += ["## Data drift (PSI: below 0.10 stable, 0.10 to 0.25 moderate, above 0.25 significant)", ""]
    if ref is None:
        L += ["No reference file (`models/reference_stats.json`). Run `python monitoring.py build-reference`.", ""]
    elif not drift["enough_data"]:
        L += [f"Not enough valid requests yet ({drift['n']} of {MIN_DRIFT_ROWS} needed); PSI is unreliable on small samples.", ""]
    else:
        L += ["| Feature | PSI | Status |", "|---|---|---|"]
        for k, v in drift["features"].items():
            L.append(f"| {k} | {v['psi']:.3f} | {v['status']} |")
            if v["status"] == "significant":
                alerts.append(f"Significant drift in {k} (PSI {v['psi']:.2f}).")
        L.append("")

    L += ["## Accuracy against real sale prices", ""]
    if not perf["enough_data"]:
        L += [f"Not enough outcomes yet ({perf['n']} of {MIN_OUTCOMES} needed).", ""]
    else:
        m, b = perf["metrics"], perf["baseline"]
        L += ["| Metric | Now | Baseline |", "|---|---|---|",
              f"| MAE | ${m['mae']:,.0f} | ${b['mae']:,.0f} |",
              f"| RMSLE | {m['rmsle']:.3f} | {b['rmsle']:.3f} |",
              f"| Within 15% of actual | {m['within_15pct']:.0%} | {b['within_15pct']:.0%} |",
              f"| Typical range coverage | {m['range_coverage']:.0%} | {b['range_coverage']:.0%} |" if b.get('range_coverage') else f"| Typical range coverage | {m['range_coverage']:.0%} | n/a |",
              f"| Median bias | {m['median_bias_pct']:+.1f}% | |", "", f"Based on {perf['n']} estimates with a known sale price. Baseline: {b['source']}.", ""]
        alerts += perf["alerts"]

    L += ["## Alerts", ""] + ([f"- {a}" for a in alerts] if alerts else ["None."])
    if alerts:
        L += ["", "Action: review the data and consider retraining (see the maintenance plan, section 3)."]
    return "\n".join(L) + "\n", alerts


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("report"); r.add_argument("--db"); r.add_argument("--out", default=str(ROOT / "reports/monitoring_report.md"))
    r.add_argument("--title", default="Monitoring report")
    b = sub.add_parser("build-reference"); b.add_argument("--data", default=str(ROOT / "data/train.csv"))
    a = ap.parse_args()

    import artifacts
    import housing as h
    model, _, info = artifacts.load_artifacts()
    if a.cmd == "build-reference":
        df = h.remove_outliers(pd.read_csv(a.data))
        write_reference(df, model)
        print(f"Wrote {REFERENCE_PATH} from {len(df)} homes.")
        return
    log = plog.read_log(Path(a.db) if a.db else None)
    text, alerts = make_report(log, info, load_reference(), a.title, artifacts.load_app_baseline())
    Path(a.out).write_text(text)
    print(text)
    raise SystemExit(1 if alerts else 0)  # non-zero exit lets a scheduler or CI notice alerts


if __name__ == "__main__":
    main()
