"""Responsible-AI audit: does the model make bigger or one-sided errors for some neighbourhoods or price bands?

    python fairness_audit.py          # reads reports/test_predictions.csv (the 292 held-out homes, scored once)

Writes reports/fairness_audit.csv and reports/fairness_audit.md.
Groups with fewer than MIN_N homes are listed but marked 'too few to judge': with 292 homes, most neighbourhoods
have only a handful of sales, so this audit can raise questions but cannot clear a neighbourhood.
Neighbourhood can stand in for protected characteristics, so a gap here is a reason to investigate, not a conclusion.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).parent
MIN_N = 8                 # smallest group we are willing to judge
ABS_ERR_FLAG = 12.0       # median absolute error (%) above which a group is flagged (plan, section 1)
BIAS_FLAG = 5.0           # median signed error (%) beyond which errors are one-sided (over- or under-estimating)


def summarise(df: pd.DataFrame, by: str) -> pd.DataFrame:
    g = df.groupby(by)
    out = pd.DataFrame({
        "homes": g.size(),
        "median_abs_err_pct": g["abs_err_pct"].median(),
        "median_signed_err_pct": g["err_pct"].median(),
        "within_15pct": g["abs_err_pct"].apply(lambda s: float((s <= 15).mean())),
        "median_price": g["SalePrice"].median(),
    })
    out["group_type"] = by
    status = []
    for _, r in out.iterrows():
        if r["homes"] < MIN_N:
            status.append("too few to judge")
        elif r["median_abs_err_pct"] > ABS_ERR_FLAG:
            status.append("FLAG: large errors")
        elif abs(r["median_signed_err_pct"]) > BIAS_FLAG:
            status.append("FLAG: one-sided " + ("over" if r["median_signed_err_pct"] > 0 else "under") + "-estimates")
        else:
            status.append("ok")
    out["status"] = status
    return out.reset_index().rename(columns={by: "group"})


def run(df: pd.DataFrame) -> pd.DataFrame:
    # err_pct in the file is (pred - actual) / actual * 100, so positive means the model over-estimated
    return pd.concat([summarise(df, "band"), summarise(df, "Neighborhood").sort_values("median_abs_err_pct", ascending=False)],
                     ignore_index=True)


def to_markdown(t: pd.DataFrame, overall: dict) -> str:
    L = ["# Fairness / responsible-AI audit (held-out homes)", "",
         f"Overall: {overall['n']} homes, median absolute error {overall['abs']:.1f}%, median signed error {overall['signed']:+.1f}%.",
         f"Flags: median absolute error above {ABS_ERR_FLAG:.0f}%, or median signed error beyond ±{BIAS_FLAG:.0f}% "
         f"(positive = over-estimate). Groups under {MIN_N} homes are not judged.", ""]
    for kind, title in [("band", "By price band"), ("Neighborhood", "By neighbourhood")]:
        L += [f"## {title}", "", "| Group | Homes | Median abs. error | Median signed error | Within 15% | Status |", "|---|---|---|---|---|---|"]
        for _, r in t[t.group_type == kind].iterrows():
            L.append(f"| {r['group']} | {r['homes']} | {r['median_abs_err_pct']:.1f}% | {r['median_signed_err_pct']:+.1f}% | "
                     f"{r['within_15pct']:.0%} | {r['status']} |")
        L.append("")
    judged = t[t.status != "too few to judge"]
    flagged = judged[judged.status.str.startswith("FLAG")]
    judged_nb = int(((t.group_type == "Neighborhood") & (t.status != "too few to judge")).sum())
    n_nb = int((t.group_type == "Neighborhood").sum())
    small = t[(t.status == "too few to judge") & (t.median_abs_err_pct > ABS_ERR_FLAG) & (t.group_type == "Neighborhood")]
    L += ["## Reading this", "",
          f"- {len(flagged)} of {len(judged)} judged groups are flagged: " + (", ".join(map(str, flagged["group"])) or "none") + ".",
          "- Not judged, but worth watching (large errors on fewer than %d homes): %s." % (MIN_N, ", ".join(
              f"{r['group']} ({r['median_signed_err_pct']:+.0f}%, n={r['homes']})" for _, r in small.iterrows()) or "none"),
          f"- Only {judged_nb} of {n_nb} neighbourhoods have {MIN_N}+ held-out homes, so the rest cannot be judged from this sample.",
          "- Price bands are a fairness concern in their own right: if the cheapest homes are over-estimated, lower-income "
          "buyers and sellers bear the larger error.",
          "- Before any real use, repeat this audit on a larger, more recent sample and add checks for the people and areas affected.", ""]
    return "\n".join(L)


def main() -> None:
    df = pd.read_csv(ROOT / "reports/test_predictions.csv")
    t = run(df)
    t.to_csv(ROOT / "reports/fairness_audit.csv", index=False)
    md = to_markdown(t, {"n": len(df), "abs": df["abs_err_pct"].median(), "signed": df["err_pct"].median()})
    (ROOT / "reports/fairness_audit.md").write_text(md)
    print(md)


if __name__ == "__main__":
    main()
