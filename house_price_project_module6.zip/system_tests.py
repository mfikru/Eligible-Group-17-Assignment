"""Whole-system tests (Module 5, Stage 8).

Runs realistic good and bad inputs through the same chain the app uses
(input -> validation -> preprocessing -> model -> output) and records Input / Expected / Actual / Pass-Fail.
Also drives the real Streamlit app headlessly. Writes reports/system_tests.csv.

Usage: python system_tests.py
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path

import joblib
import pandas as pd

import housing as h

ROOT = Path(__file__).parent

BASE = {"Neighborhood": "NAmes", "GrLivArea": 1500, "Stories": 1, "LotArea": 9000, "OverallQual": 6,
        "OverallCond": 5, "YearBuilt": 1975, "YearRemodAdd": 1990, "GarageCars": 2, "TotalBsmtSF": 900,
        "FullBath": 2, "HalfBath": 0, "KitchenQual": "TA"}


def load():
    model = joblib.load(ROOT / "models/price_model.joblib")
    defaults = json.loads((ROOT / "models/defaults.json").read_text())
    info = json.loads((ROOT / "reports/metrics.json").read_text())
    return model, defaults, info["holdout_rmsle"]


def describe(out: dict) -> str:
    if not out["ok"]:
        return "Rejected: " + " ".join(out["errors"])
    r = out["result"]
    s = f"Estimate ${r['price']:,.0f}"
    if out["warnings"]:
        s += " with warning: " + " ".join(out["warnings"])
    return s


def run_cases() -> pd.DataFrame:
    # the system tests must never write to the real prediction log
    os.environ["PRICE_LOG"] = "1"
    os.environ["PRICE_LOG_DB"] = str(Path(tempfile.mkdtemp()) / "system_tests.db")
    model, defaults, rmsle = load()
    run = lambda **ch: h.safe_estimate(model, defaults, {**BASE, **ch}, rmsle)  # noqa: E731
    price = lambda o: o["result"]["price"] if o["ok"] else float("nan")  # noqa: E731
    rejected = lambda *words: (lambda o: (not o["ok"]) and all(w.lower() in " ".join(o["errors"]).lower() for w in words))  # noqa: E731
    cases = []

    def add(group, name, shown, expected, out, passed):
        cases.append(dict(group=group, test_case=name, input=shown, expected=expected, actual=describe(out),
                          result="Pass" if passed else "FAIL"))

    o = run()
    add("Normal", "Normal, complete input", "Typical North Ames home, 1,500 sq ft, quality 6",
        "Estimate between $100,000 and $260,000, no warnings", o,
        o["ok"] and 100_000 < price(o) < 260_000 and not o["warnings"])
    o = run(Neighborhood="NridgHt", Stories=2, GrLivArea=2600, OverallQual=9, YearBuilt=2005, YearRemodAdd=2005,
            KitchenQual="Gd", FullBath=2, HalfBath=1, GarageCars=3)
    add("Normal", "High-end home", "Northridge Heights, 2 stories, 2,600 sq ft, quality 9, built 2005",
        "Estimate above $250,000", o, o["ok"] and price(o) > 250_000)
    o = run(Neighborhood="OldTown", GrLivArea=900, OverallQual=4, YearBuilt=1925, YearRemodAdd=1950, GarageCars=0,
            TotalBsmtSF=0, FullBath=1)
    add("Normal", "Small old home, no garage, no basement", "Old Town, 900 sq ft, quality 4, built 1925",
        "Estimate below $120,000", o, o["ok"] and price(o) < 120_000)
    o = run(GrLivArea="1,500")
    add("Normal", "Number typed with a thousands comma", "GrLivArea = '1,500'", "Accepted and same as 1500", o,
        o["ok"] and abs(price(o) - price(run())) < 1e-6)

    o = run(GrLivArea=None)
    add("Missing value", "Missing living area", "GrLivArea = None", "Clear message, no estimate", o,
        rejected("living area", "required")(o))
    o = run(KitchenQual="")
    add("Missing value", "Empty kitchen quality", "KitchenQual = ''", "Clear message, no estimate", o,
        rejected("kitchen", "required")(o))
    o = run(Neighborhood=None)
    add("Missing value", "Missing neighbourhood", "Neighborhood = None", "Clear message, no estimate", o,
        rejected("neighbourhood", "required")(o))
    o = run(OverallCond=None)
    add("Missing value", "Missing optional condition rating", "OverallCond = None",
        "Estimate using the neighbourhood's typical condition", o, o["ok"])

    for label, ch, words in [
        ("Text instead of a number", dict(GrLivArea="abc"), ("living area", "number")),
        ("Not-a-number value", dict(LotArea=float("nan")), ("lot size", "finite")),
        ("Infinite value", dict(LotArea=float("inf")), ("lot size", "finite")),
        ("Negative area", dict(GrLivArea=-5), ("living area", "between")),
        ("Quality not a whole number", dict(OverallQual=6.5), ("quality", "whole")),
        ("Quality out of range", dict(OverallQual=11), ("quality", "between")),
        ("Year built in the future", dict(YearBuilt=2025, YearRemodAdd=2025), ("year built", "between")),
        ("Boolean in a number field", dict(FullBath=True), ("full bathrooms", "number")),
        ("Stories not 1 or 2", dict(Stories=5), ("stories", "between")),
    ]:
        k, v = next(iter(ch.items()))
        o = run(**ch)
        add("Invalid input", label, f"{k} = {v!r}", "Rejected safely with a message naming the field", o, rejected(*words)(o))

    for label, v in [("Neighbourhood sent as a number", 5), ("Neighbourhood sent as a list", ["NAmes"])]:
        o = run(Neighborhood=v)
        add("Invalid input", label, f"Neighborhood = {v!r}", "Rejected safely with a message naming the field", o,
            rejected("neighbourhood", "text")(o))
    o = run(KitchenQual="XX")
    add("Unexpected category", "Unknown kitchen quality code", "KitchenQual = 'XX'",
        "Rejected, message lists allowed values", o, rejected("kitchen", "Ex, Gd, TA, Fa, Po")(o))
    o = run(Neighborhood="Atlantis")
    add("Unexpected category", "Unknown neighbourhood", "Neighborhood = 'Atlantis'",
        "Estimate from city-wide typical values plus a warning", o, o["ok"] and any("not one the model" in w for w in o["warnings"]))
    o = run(Neighborhood="  names ")
    add("Unexpected category", "Neighbourhood typed in different case with spaces", "Neighborhood = '  names '",
        "Matched to NAmes, same estimate as the normal case", o, o["ok"] and abs(price(o) - price(run())) < 1e-6)

    o = run(GrLivArea=9000)
    add("Extreme value", "Very large house", "GrLivArea = 9,000", "Estimate with an extrapolation warning", o,
        o["ok"] and any("extrapolation" in w for w in o["warnings"]))
    o = run(GrLivArea=50)
    add("Extreme value", "Impossibly small house", "GrLivArea = 50", "Rejected (below 200 sq ft)", o, rejected("living area")(o))
    o = run(LotArea=150_000)
    add("Extreme value", "Huge lot", "LotArea = 150,000", "Estimate with a warning", o,
        o["ok"] and any("lot size" in w.lower() for w in o["warnings"]))
    o = run(YearBuilt=1990, YearRemodAdd=1950)
    add("Extreme value", "Remodel year before build year", "Built 1990, remodelled 1950",
        "Estimate with a correction warning", o, o["ok"] and any("remodel" in w.lower() for w in o["warnings"]))
    o = run(YearBuilt=1805, YearRemodAdd=1805)
    add("Extreme value", "Very old home", "Built 1805", "Estimate with a warning", o,
        o["ok"] and any("earlier than any home" in w for w in o["warnings"]))

    # REST API (same validation and model), driven in-process
    try:
        from fastapi.testclient import TestClient
        import api, prediction_log as plog
    except ImportError:
        TestClient = None
    if TestClient:
        with TestClient(api.app) as c:
            r = c.get("/health")
            cases.append(dict(group="API", test_case="Health check", input="GET /health", expected="200 and status ok",
                              actual=f"{r.status_code} {r.json()}", result="Pass" if r.status_code == 200 and r.json()["status"] == "ok" else "FAIL"))
            r = c.post("/predict", json=BASE); j = r.json()
            same = r.status_code == 200 and abs(j["price"] - price(run())) < 1e-6
            cases.append(dict(group="API", test_case="Valid request", input="POST /predict with the normal home",
                              expected="200 and the same price as the app", actual=f"{r.status_code} ${j.get('price', 0):,.0f}",
                              result="Pass" if same else "FAIL"))
            r = c.post("/predict", json={**BASE, "GrLivArea": 50})
            cases.append(dict(group="API", test_case="Invalid request", input="POST /predict with GrLivArea = 50",
                              expected="422 with a message naming the field", actual=f"{r.status_code} " + str(r.json()["detail"]["errors"])[:80],
                              result="Pass" if r.status_code == 422 and "Living area" in str(r.json()) else "FAIL"))
            r = c.post("/predict", content=b"[1, 2]", headers={"content-type": "application/json"})
            cases.append(dict(group="API", test_case="Body is not a JSON object", input="POST /predict with [1, 2]",
                              expected="422, no crash", actual=str(r.status_code), result="Pass" if r.status_code == 422 else "FAIL"))
            r = c.post("/outcome", json={"request_id": j["request_id"], "actual_price": 150_000})
            logged = plog.read_log()
            cases.append(dict(group="API", test_case="Requests logged and sale price recorded", input="2 requests, then POST /outcome",
                              expected="Both requests in the log; outcome stored", actual=f"{len(logged)} logged, outcome {r.status_code}",
                              result="Pass" if len(logged) == 2 and r.status_code == 200 and logged["actual_price"].notna().sum() == 1 else "FAIL"))

    lo, hi = price(run(OverallQual=4)), price(run(OverallQual=8))
    add("Model behaviour", "Higher quality gives a higher price", "Quality 4 vs 8", "Price(8) > Price(4)",
        dict(ok=True, warnings=[], result=dict(price=hi), errors=[]), hi > lo)
    lo, hi = price(run(GrLivArea=1000)), price(run(GrLivArea=2200))
    add("Model behaviour", "Larger house costs more", "1,000 vs 2,200 sq ft", "Price(2,200) > Price(1,000)",
        dict(ok=True, warnings=[], result=dict(price=hi), errors=[]), hi > lo)

    t = time.time()
    for _ in range(10):
        run()
    sec = (time.time() - t) / 10
    add("Performance", "Response time", "10 repeated estimates", "Under 2 seconds each",
        dict(ok=True, warnings=[], result=dict(price=price(run())), errors=[]), sec < 2.0)
    cases[-1]["actual"] = f"{sec:.2f} s per estimate"

    # the real app, headless
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=90).run()
    ok1 = not at.exception and any("$" in m.value for m in at.metric)
    first = at.metric[0].value if ok1 else "n/a"
    at.slider[0].set_value(9).run()
    ok2 = not at.exception and at.metric[0].value != first
    cases.append(dict(group="Whole app", test_case="App loads and shows an estimate", input="Default form values",
                      expected="Estimate shown, no error", actual=f"Estimate shown: {first}" if ok1 else "Failed",
                      result="Pass" if ok1 else "FAIL"))
    cases.append(dict(group="Whole app", test_case="Changing an input updates the estimate",
                      input="Overall quality slider moved to 9", expected="Different estimate, no error",
                      actual=f"Estimate now {at.metric[0].value}" if ok2 else "No change or error",
                      result="Pass" if ok2 else "FAIL"))
    at.number_input[0].set_value(50).run()  # below the hard limit: the app must show a message, not crash
    ok3 = not at.exception and len(at.error) > 0
    cases.append(dict(group="Whole app", test_case="Invalid value typed into the app", input="Living area = 50",
                      expected="Error message shown, no estimate, no crash",
                      actual=("Error shown: " + at.error[0].value[:90]) if ok3 else "No message or crashed",
                      result="Pass" if ok3 else "FAIL"))

    # logging and feedback inside the app (fresh session)
    import prediction_log as plog
    os.environ["PRICE_LOG_DB"] = str(Path(tempfile.mkdtemp()) / "app.db")
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=90).run()
    at.number_input[-1].set_value(155_000).run()
    next(b for b in at.button if b.label == "Record sale price").click().run()
    log = plog.read_log()
    ok4 = not at.exception and len(log) == 1 and log.iloc[0]["source"] == "streamlit" and log.iloc[0]["actual_price"] == 155_000
    cases.append(dict(group="Whole app", test_case="Estimate is logged and the real sale price can be recorded",
                      input="Default form, then 'Record sale price' = 155,000",
                      expected="One log row from the app with the sale price attached, no personal fields",
                      actual=f"{len(log)} row(s) logged" + ("; sale price attached" if ok4 else "; check failed"),
                      result="Pass" if ok4 else "FAIL"))

    df = pd.DataFrame(cases)
    df.to_csv(ROOT / "reports/system_tests.csv", index=False)
    return df


if __name__ == "__main__":
    pd.set_option("display.width", 250, "display.max_colwidth", 70)
    d = run_cases()
    print(d[["group", "test_case", "result"]].to_string(index=False))
    print(f"\n{(d.result == 'Pass').sum()} of {len(d)} passed")
