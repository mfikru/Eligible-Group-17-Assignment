"""Data inspection and exploratory data analysis (Module 5, Stages 3 and 4).

Every function returns numbers or a figure that answers one question; the interpretation is written next to it
in the report notebook. Figures are also saved to reports/figures/.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

import housing as h  # noqa: E402

ROOT = Path(__file__).parent
FIG = ROOT / "reports/figures"
BLUE, RED, GREY = "#2b6cb0", "#c53030", "#718096"


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG / f"{name}.png", dpi=130, bbox_inches="tight")
    return fig


# --------------------------------------------------------------------------- #
# Stage 3: quality log
# --------------------------------------------------------------------------- #
def quality_log(raw: pd.DataFrame) -> pd.DataFrame:
    """One row per data problem: what was found (computed from the data), and what was done."""
    n = len(raw)
    na = raw.isna().sum()
    none_cols = [c for c in h.NONE_CATS if na.get(c, 0) > 0]
    pre = h.AmesPreprocessor().fit(h.remove_outliers(raw))
    ext_rows = int(raw["Exterior2nd"].isin(h.EXTERIOR_FIX).sum())
    outl = raw[(raw["GrLivArea"] > 4000) & (raw["SalePrice"] < 300_000)]
    rows = [
        ("Missing values that mean 'feature absent'",
         f"{len(none_cols)} columns, e.g. PoolQC {na['PoolQC']} of {n}, MiscFeature {na['MiscFeature']}, "
         f"Alley {na['Alley']}, Fence {na['Fence']}, FireplaceQu {na['FireplaceQu']}, "
         f"Garage fields {na['GarageType']}, Basement fields {na['BsmtQual']}",
         "Filled with the category 'None' (numeric size fields with 0). Row deletion would have thrown away most "
         "of the data, and the data dictionary says NA means 'no such feature'."),
        ("Genuinely missing: LotFrontage", f"{na['LotFrontage']} homes ({na['LotFrontage'] / n:.1%})",
         "Imputed with the median LotFrontage of the home's neighbourhood (frontage depends on the area), falling "
         "back to the citywide median. Learned from training rows only."),
        ("Genuinely missing: Electrical, MasVnrType/Area",
         f"Electrical {na['Electrical']}, MasVnrArea {na['MasVnrArea']}",
         "Electrical set to the most common value (SBrkr); veneer area set to 0 and type to 'None'."),
        ("Duplicate rows", f"{int(raw.duplicated().sum())} duplicate rows, {int(raw['Id'].duplicated().sum())} duplicate Ids",
         "None needed. Count was 1,460 before and after."),
        ("Inconsistent category spellings",
         f"Exterior2nd uses 'Brk Cmn', 'CmentBd', 'Wd Shng' while Exterior1st uses 'BrkComm', 'CemntBd', "
         f"'WdShing' for the same materials ({ext_rows} homes affected)",
         "Exterior2nd standardised to the Exterior1st spelling."),
        ("Impossible values",
         f"Remodel before build: {int((raw.YearRemodAdd < raw.YearBuilt).sum())}; built after sale: "
         f"{int((raw.YearBuilt > raw.YrSold).sum())}; negative areas: "
         f"{int((raw.select_dtypes('number') < 0).sum().sum())}",
         "None found. The same rules are enforced on user input in the app."),
        ("Extreme values (outliers)",
         f"{len(outl)} homes with living area over 4,000 sq ft sold for under $300,000 "
         f"(areas {', '.join(str(int(a)) for a in outl.GrLivArea)}; prices "
         f"{', '.join('$' + format(int(p), ',') for p in outl.SalePrice)})",
         "Removed from training and testing. The dataset author documents them as partial sales that do not reflect "
         "market value. Dropping them was tested against keeping them (see experiment log)."),
        ("Skewed target", f"SalePrice skewness {raw.SalePrice.skew():.2f}; after log1p {np.log1p(raw.SalePrice).skew():.2f}",
         "Model trained on log(1 + price) and converted back. This also matches the RMSLE metric."),
        ("Skewed numeric features", f"{len(pre.log_cols_)} numeric features with |skew| above 0.75",
         "log1p transform, chosen on training data only."),
        ("Columns that should not be used",
         f"Id; SaleType, SaleCondition, MoSold, YrSold (unknown before a sale); Utilities (only "
         f"{int((raw.Utilities != 'AllPub').sum())} home differs); GarageYrBlt and YearBuilt/YearRemodAdd (replaced by ages)",
         "Dropped. Ages are measured to 2010, the last sale year in the data."),
        ("Numeric codes that are really categories", "MSSubClass holds dwelling-type codes (20, 60, ...)",
         "Converted to text and one-hot encoded."),
        ("Rare categories",
         f"{int((raw.Neighborhood.value_counts() < 10).sum())} neighbourhoods have under 10 homes "
         f"(Blueste has {int(raw.Neighborhood.value_counts().min())})",
         "Categories with fewer than 3 training homes are ignored by the encoder; the app warns for unknown "
         "neighbourhoods. Accuracy in small neighbourhoods is less certain."),
    ]
    return pd.DataFrame(rows, columns=["Problem", "Evidence", "Action taken and reason"])


def descriptive_table(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["SalePrice", "GrLivArea", "LotArea", "TotalBsmtSF", "OverallQual", "OverallCond", "YearBuilt",
            "GarageCars", "FullBath"]
    t = df[cols].describe().T[["count", "mean", "50%", "min", "max", "std"]]
    t.columns = ["count", "mean", "median", "min", "max", "std"]
    t["skew"] = df[cols].skew()
    return t.round(2)


def variable_overview(raw: pd.DataFrame) -> pd.DataFrame:
    """Type, range / levels and missing count for every raw column."""
    rows = []
    for c in raw.columns:
        s = raw[c]
        if pd.api.types.is_numeric_dtype(s):
            rng = f"{s.min():,.0f} to {s.max():,.0f}"
            kind = "numeric"
        else:
            rng = f"{s.nunique()} levels"
            kind = "categorical"
        rows.append((c, kind, rng, int(s.isna().sum())))
    return pd.DataFrame(rows, columns=["variable", "type", "range or levels", "missing"])


# --------------------------------------------------------------------------- #
# Stage 4: figures
# --------------------------------------------------------------------------- #
def fig_target(df):
    """Is the target skewed? Does a log transform fix it?"""
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].hist(df.SalePrice / 1e3, bins=40, color=BLUE)
    ax[0].axvline(df.SalePrice.median() / 1e3, color=RED, ls="--", label="median")
    ax[0].axvline(df.SalePrice.mean() / 1e3, color="black", ls=":", label="mean")
    ax[0].set(title=f"Sale price (skew {df.SalePrice.skew():.2f})", xlabel="USD thousands", ylabel="homes")
    ax[0].legend()
    ax[1].hist(np.log1p(df.SalePrice), bins=40, color=BLUE)
    ax[1].set(title=f"log(1 + price) (skew {np.log1p(df.SalePrice).skew():.2f})", xlabel="log price")
    fig.tight_layout()
    return _save(fig, "01_target_distribution")


def fig_missing(raw):
    """Where is data missing, and is it really missing?"""
    na = raw.isna().sum().sort_values(ascending=False)
    na = na[na > 0].head(16)[::-1]
    colors = [BLUE if c in h.NONE_CATS else RED for c in na.index]
    fig, ax = plt.subplots(figsize=(7, 4.6))
    ax.barh(na.index, na.values / len(raw) * 100, color=colors)
    ax.set(xlabel="% of homes with NA", title="Missing values: blue = NA means 'no such feature', red = truly missing")
    ax.title.set_fontsize(10)
    fig.tight_layout()
    return _save(fig, "02_missing_values")


def fig_outliers(raw):
    """Are there extreme homes that do not follow the pattern?"""
    out = (raw.GrLivArea > 4000) & (raw.SalePrice < 300_000)
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.scatter(raw.GrLivArea[~out], raw.SalePrice[~out] / 1e3, s=10, alpha=0.5, color=BLUE)
    ax.scatter(raw.GrLivArea[out], raw.SalePrice[out] / 1e3, s=60, color=RED, label="removed outliers")
    ax.set(xlabel="Living area (sq ft)", ylabel="Price (USD thousands)", title="Living area vs price")
    ax.legend()
    fig.tight_layout()
    return _save(fig, "03_area_vs_price_outliers")


def fig_quality(df):
    """Does build quality separate prices?"""
    fig, ax = plt.subplots(figsize=(7, 4))
    groups = [df.loc[df.OverallQual == q, "SalePrice"] / 1e3 for q in range(1, 11)]
    ax.boxplot(groups, labels=range(1, 11), showfliers=True, flierprops=dict(markersize=3))
    ax.set(xlabel="Overall quality (1 to 10)", ylabel="Price (USD thousands)", title="Price by overall quality")
    fig.tight_layout()
    return _save(fig, "04_quality_vs_price")


def fig_neighborhood(df):
    """How much does location matter?"""
    g = df.groupby("Neighborhood")["SalePrice"].agg(["median", "size"]).sort_values("median")
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.barh(g.index, g["median"] / 1e3, color=BLUE)
    for i, (m, n) in enumerate(zip(g["median"], g["size"])):
        ax.text(m / 1e3 + 2, i, f"n={n}", va="center", fontsize=7, color=GREY)
    ax.set(xlabel="Median price (USD thousands)", title="Median price by neighbourhood (n = homes)")
    fig.tight_layout()
    return _save(fig, "05_neighbourhood_prices")


def correlation_with_target(df, k=12):
    pre = h.AmesPreprocessor().fit(df)
    X = pre.transform(df)[pre.num_cols_]
    c = X.corrwith(pd.Series(np.log1p(df.SalePrice.values), index=X.index))
    return c.reindex(c.abs().sort_values(ascending=False).index).head(k)


def fig_correlation(df):
    """Which numeric features track price, and which features overlap with each other?"""
    pre = h.AmesPreprocessor().fit(df)
    X = pre.transform(df)[pre.num_cols_]
    top = correlation_with_target(df, 12)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.8), gridspec_kw=dict(width_ratios=[1, 1.15]))
    t = top[::-1]
    ax[0].barh(t.index, t.values, color=BLUE)
    ax[0].set(xlabel="Correlation with log price", title="Top 12 features by correlation with price")
    cols = list(top.index[:8])
    cm = X[cols].corr()
    im = ax[1].imshow(cm, vmin=-1, vmax=1, cmap="RdBu_r")
    ax[1].set_xticks(range(len(cols)), cols, rotation=60, ha="right", fontsize=8)
    ax[1].set_yticks(range(len(cols)), cols, fontsize=8)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax[1].text(j, i, f"{cm.iloc[i, j]:.2f}", ha="center", va="center", fontsize=7)
    ax[1].set_title("How the top 8 overlap with each other")
    fig.colorbar(im, ax=ax[1], fraction=0.046)
    fig.tight_layout()
    return _save(fig, "06_correlations")


def fig_age(df):
    """Does age matter, and does remodelling offset it?"""
    d = df.assign(age=h.SALE_YEAR - df.YearBuilt, remod=(df.YearRemodAdd != df.YearBuilt))
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    for flag, color, lab in [(False, BLUE, "never remodelled"), (True, RED, "remodelled")]:
        s = d[d.remod == flag]
        ax.scatter(s.age, s.SalePrice / 1e3, s=9, alpha=0.5, color=color, label=lab)
    ax.set(xlabel="House age in 2010 (years)", ylabel="Price (USD thousands)", title="Price by age")
    ax.legend()
    fig.tight_layout()
    return _save(fig, "07_age_vs_price")


def group_comparison(df) -> pd.DataFrame:
    """Median price for a few useful groups."""
    rows = []
    for label, mask in [
        ("Central air: yes", df.CentralAir == "Y"), ("Central air: no", df.CentralAir == "N"),
        ("Garage: 0 cars", df.GarageCars == 0), ("Garage: 2 cars", df.GarageCars == 2),
        ("Built before 1950", df.YearBuilt < 1950), ("Built 2000 or later", df.YearBuilt >= 2000),
        ("One story", df.HouseStyle == "1Story"), ("Two stories", df.HouseStyle == "2Story"),
    ]:
        rows.append((label, int(mask.sum()), df.loc[mask, "SalePrice"].median()))
    return pd.DataFrame(rows, columns=["group", "homes", "median_price"])
