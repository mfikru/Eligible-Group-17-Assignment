import pandas as pd

import housing as h
import prediction_log as plog


def _estimate(art, inputs):
    model, defaults, info = art
    return h.safe_estimate(model, defaults, inputs, info["holdout_rmsle"])


def test_round_trip_and_outcome(art, base):
    rid = plog.log_prediction(base, _estimate(art, base), source="test", model_version="v1", latency_ms=12.5)
    assert rid
    assert plog.log_outcome(rid, 150_000)
    df = plog.read_log()
    assert len(df) == 1
    row = df.iloc[0]
    assert row["ok"] == 1 and row["actual_price"] == 150_000 and row["GrLivArea"] == 1500
    assert row["model_version"] == "v1" and row["latency_ms"] == 12.5


def test_rejected_requests_are_logged_with_errors(art, base):
    bad = {**base, "GrLivArea": 50}
    plog.log_prediction(bad, _estimate(art, bad), source="test")
    row = plog.read_log().iloc[0]
    assert row["ok"] == 0 and "Living area" in row["errors"] and pd.isna(row["price"])


def test_outcome_rejects_unknown_id_and_bad_prices(art, base):
    rid = plog.log_prediction(base, _estimate(art, base), source="test")
    assert not plog.log_outcome("does-not-exist", 100_000)
    for bad in (0, -5, "abc", None, float("inf")):
        assert not plog.log_outcome(rid, bad)
    assert plog.read_log()["actual_price"].isna().all()


def test_outcome_not_allowed_for_rejected_request(art, base):
    bad = {**base, "GrLivArea": 50}
    rid = plog.log_prediction(bad, _estimate(art, bad), source="test")
    assert not plog.log_outcome(rid, 100_000)


def test_logging_can_be_switched_off(art, base, monkeypatch):
    monkeypatch.setenv("PRICE_LOG", "0")
    assert plog.log_prediction(base, _estimate(art, base), source="test") is None
    assert not plog.db_path().exists()


def test_logging_failure_never_breaks_the_caller(art, base, tmp_path):
    # a directory is not a valid database file: the call must return None, not raise
    assert plog.log_prediction(base, _estimate(art, base), source="test", path=tmp_path) is None


def test_no_personal_fields_are_stored(art, base):
    plog.log_prediction(base, _estimate(art, base), source="test")
    cols = {c.lower() for c in plog.read_log().columns}
    assert not cols & {"name", "email", "address", "ip", "phone", "user"}
