import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")
from fastapi.testclient import TestClient  # noqa: E402

import api  # noqa: E402
import housing as h  # noqa: E402
import prediction_log as plog  # noqa: E402


@pytest.fixture
def client():
    with TestClient(api.app) as c:
        yield c


def test_health_and_model_info(client):
    assert client.get("/health").json()["status"] == "ok"
    info = client.get("/model-info").json()
    assert info["training_rows"] == 1458 and info["valuation_year"] == 2010


def test_predict_matches_the_library_function(client, art, base):
    r = client.post("/predict", json=base)
    assert r.status_code == 200
    body = r.json()
    model, defaults, info = art
    expected = h.safe_estimate(model, defaults, base, info["holdout_rmsle"])["result"]["price"]
    assert body["price"] == pytest.approx(expected)
    assert body["low"] < body["price"] < body["high"]
    assert len(body["drivers"]) == 5 and body["request_id"]


def test_invalid_input_returns_422_with_named_field(client, base):
    r = client.post("/predict", json={**base, "GrLivArea": 50})
    assert r.status_code == 422
    assert "Living area" in " ".join(r.json()["detail"]["errors"])


@pytest.mark.parametrize("payload", [{}, {"GrLivArea": "big"}, {"OverallQual": 11}, {"Neighborhood": 5}])
def test_bad_payloads_are_rejected_not_crashed(client, base, payload):
    r = client.post("/predict", json={**base, **payload} if payload else {})
    assert r.status_code == 422


def test_non_object_body_is_rejected(client):
    r = client.post("/predict", content=b"[1, 2]", headers={"content-type": "application/json"})
    assert r.status_code == 422


def test_unknown_neighbourhood_gives_estimate_with_warning(client, base):
    r = client.post("/predict", json={**base, "Neighborhood": "Atlantis"})
    assert r.status_code == 200 and r.json()["warnings"]


def test_requests_are_logged_and_outcome_can_be_recorded(client, base):
    ok = client.post("/predict", json=base).json()
    client.post("/predict", json={**base, "GrLivArea": 50})
    assert client.post("/outcome", json={"request_id": ok["request_id"], "actual_price": 155_000}).status_code == 200
    log = plog.read_log()
    assert list(log["ok"]) == [1, 0] and log.iloc[0]["actual_price"] == 155_000
    assert set(log["source"]) == {"api"}


def test_outcome_with_unknown_id_is_404(client):
    assert client.post("/outcome", json={"request_id": "nope", "actual_price": 1}).status_code == 404
