import shutil

import pytest

pytest.importorskip("mlflow")
pytest.importorskip("sqlalchemy")

import log_to_mlflow as lm  # noqa: E402


def test_logs_all_candidate_models_and_the_final_run(tmp_path, monkeypatch):
    import mlflow
    for f in ("reports/metrics.json", "reports/model_comparison.csv", "reports/tuning_log.csv",
              "reports/experiment_log.csv", "models/best_params.json"):
        (tmp_path / f).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(lm.ROOT / f, tmp_path / f)
    monkeypatch.setattr(lm, "ROOT", tmp_path)
    lm.main()
    exp = mlflow.get_experiment_by_name(lm.EXPERIMENT)
    runs = mlflow.search_runs([exp.experiment_id])
    assert len(runs) == 9  # 8 compared models + the final run
    final = runs[runs["tags.stage"].str.startswith("final")].iloc[0]
    assert final["metrics.holdout_rmsle"] == pytest.approx(0.1108, abs=1e-3)
