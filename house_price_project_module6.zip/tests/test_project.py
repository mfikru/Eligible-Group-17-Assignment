import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import housing as h  # noqa: E402


@pytest.fixture(scope="module")
def model():
    return joblib.load(ROOT / "models/price_model.joblib")


@pytest.fixture(scope="module")
def defaults():
    return json.loads((ROOT / "models/defaults.json").read_text())


@pytest.fixture(scope="module")
def info():
    return json.loads((ROOT / "reports/metrics.json").read_text())


BASE = {"Neighborhood": "NAmes", "GrLivArea": 1500, "Stories": 1, "LotArea": 9000, "OverallQual": 6,
        "OverallCond": 5, "YearBuilt": 1975, "YearRemodAdd": 1990, "GarageCars": 2, "TotalBsmtSF": 900,
        "FullBath": 2, "HalfBath": 0, "KitchenQual": "TA"}


def price(model, defaults, info, **changes):
    return h.estimate(model, defaults, {**BASE, **changes}, info["holdout_rmsle"])["price"]


def test_saved_model_reproduces_training_predictions(model):
    """Loading the saved pipeline gives the same predictions as when it was trained (serving == training)."""
    ref = json.loads((ROOT / "tests/reference_predictions.json").read_text())
    rows = pd.DataFrame(ref["rows"])
    np.testing.assert_allclose(model.predict(rows), ref["predictions"], rtol=1e-9)


def test_contributions_add_up_to_prediction(model):
    ref = pd.DataFrame(json.loads((ROOT / "tests/reference_predictions.json").read_text())["rows"])
    grouped, bias = model.contributions(ref)
    np.testing.assert_allclose(grouped.sum(axis=1).values + bias, model.predict_log(ref), atol=1e-6)


def test_typical_home_price_is_plausible(model, defaults, info):
    p = price(model, defaults, info)
    assert 100_000 < p < 260_000


@pytest.mark.parametrize("field,low,high", [
    ("OverallQual", 4, 8), ("GrLivArea", 1000, 2200), ("OverallCond", 3, 7),
    ("KitchenQual", "Fa", "Ex"), ("GarageCars", 0, 2), ("YearBuilt", 1940, 2005),
])
def test_price_moves_in_the_expected_direction(model, defaults, info, field, low, high):
    kw_low, kw_high = {field: low}, {field: high}
    if field == "YearBuilt":  # keep the remodel year consistent
        kw_low["YearRemodAdd"], kw_high["YearRemodAdd"] = low, high
    assert price(model, defaults, info, **kw_high) > price(model, defaults, info, **kw_low)


def test_edge_cases_do_not_break(model, defaults, info):
    for changes in [{"GarageCars": 0}, {"TotalBsmtSF": 0}, {"Stories": 2}, {"HalfBath": 2, "FullBath": 0},
                    {"YearRemodAdd": 1950, "YearBuilt": 1990}, {"OverallCond": None}]:
        p = price(model, defaults, info, **changes)
        assert np.isfinite(p) and p > 20_000, changes


def test_every_neighbourhood_works(model, defaults, info):
    for nb in defaults["by_neighborhood"]:
        assert np.isfinite(price(model, defaults, info, Neighborhood=nb))


def test_built_row_has_no_missing_values_after_preprocessing(model, defaults):
    X = h.build_row(BASE, defaults)
    assert X.shape[1] == len(defaults["raw_columns"])
    assert not model.pre.transform(X).isna().any().any()


def test_latency_and_size_targets(model, defaults, info):
    h.estimate(model, defaults, BASE, 0.11)
    t = time.time()
    for _ in range(10):
        h.estimate(model, defaults, BASE, 0.11)
    assert (time.time() - t) / 10 < 2.0
    assert (ROOT / "models/price_model.joblib").stat().st_size < 100e6


def test_validation_rejects_bad_input_and_accepts_good(defaults):
    ok = h.validate_inputs(BASE, defaults)
    assert not ok["errors"] and not ok["warnings"]
    for change in [{"GrLivArea": None}, {"GrLivArea": "abc"}, {"GrLivArea": -5}, {"OverallQual": 6.5},
                   {"OverallQual": 11}, {"KitchenQual": "XX"}, {"LotArea": float("nan")}, {"YearBuilt": 2025}]:
        assert h.validate_inputs({**BASE, **change}, defaults)["errors"], change


def test_validation_warns_but_allows_unknown_or_extreme(defaults):
    v = h.validate_inputs({**BASE, "Neighborhood": "Atlantis"}, defaults)
    assert not v["errors"] and v["warnings"]
    v = h.validate_inputs({**BASE, "GrLivArea": 9000}, defaults)
    assert not v["errors"] and any("extrapolation" in w for w in v["warnings"])


def test_safe_estimate_never_raises(model, defaults, info):
    for bad in [{}, {"GrLivArea": "x"}, {**BASE, "Neighborhood": 5}]:
        out = h.safe_estimate(model, defaults, bad, info["holdout_rmsle"])
        assert set(out) == {"ok", "errors", "warnings", "result"}


def test_exterior_spellings_are_standardised():
    pre = h.AmesPreprocessor()
    df = pd.DataFrame({c: [np.nan] for c in ["MSSubClass"] + h.NONE_CATS + h.ZERO_NUMS + ["Exterior2nd"]})
    df["MSSubClass"] = 20
    df["Exterior2nd"] = ["CmentBd"]
    assert pre._stage1(df)["Exterior2nd"].iloc[0] == "CemntBd"


def test_success_criteria_from_proposal(info):
    a = info["targets_vs_achieved"]
    assert a["rmsle"]["holdout"] <= a["rmsle"]["target"]
    assert a["mae_usd"]["holdout"] <= a["mae_usd"]["target"]
    assert a["r2"]["holdout"] >= a["r2"]["target"]
    assert a["within_15pct"]["holdout"] >= a["within_15pct"]["target"]
    assert a["rmsle_reduction_vs_median_baseline_pct"] >= 30
    assert a["rmsle_reduction_vs_simple_linear_pct"] >= 10


def test_streamlit_app_runs_without_errors():
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not at.exception
    assert any("$" in m.value for m in at.metric)
    at.slider[0].set_value(9).run()  # change overall quality: app still runs and the estimate changes
    assert not at.exception
