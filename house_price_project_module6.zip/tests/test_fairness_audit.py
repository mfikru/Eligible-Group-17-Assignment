import numpy as np
import pandas as pd

import fairness_audit as fa


def _frame():
    rng = np.random.default_rng(0)
    rows = []
    for nb, n, bias in [("Big", 30, 0.0), ("Biased", 20, 8.0), ("Tiny", 3, 30.0)]:
        err = rng.normal(bias, 2.0, n)
        rows += [{"Neighborhood": nb, "band": "Q1" if i % 2 else "Q2", "SalePrice": 100_000, "err_pct": e, "abs_err_pct": abs(e)}
                 for i, e in enumerate(err)]
    return pd.DataFrame(rows)


def test_flags_one_sided_groups_and_skips_tiny_ones():
    t = fa.run(_frame()).set_index(["group_type", "group"])
    assert t.loc[("Neighborhood", "Big"), "status"] == "ok"
    assert "FLAG" in t.loc[("Neighborhood", "Biased"), "status"] and "over" in t.loc[("Neighborhood", "Biased"), "status"]
    assert t.loc[("Neighborhood", "Tiny"), "status"] == "too few to judge"


def test_markdown_mentions_watch_list():
    df = _frame()
    md = fa.to_markdown(fa.run(df), {"n": len(df), "abs": 5.0, "signed": 1.0})
    assert "Tiny" in md and "Not judged" in md


def test_real_holdout_file_is_auditable():
    df = pd.read_csv(fa.ROOT / "reports/test_predictions.csv")
    t = fa.run(df)
    assert {"band", "Neighborhood"} == set(t["group_type"])
    assert t.loc[t.group_type == "band", "homes"].sum() == len(df) == 292
