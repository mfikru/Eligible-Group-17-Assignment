import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

BASE = {"Neighborhood": "NAmes", "GrLivArea": 1500, "Stories": 1, "LotArea": 9000, "OverallQual": 6,
        "OverallCond": 5, "YearBuilt": 1975, "YearRemodAdd": 1990, "GarageCars": 2, "TotalBsmtSF": 900,
        "FullBath": 2, "HalfBath": 0, "KitchenQual": "TA"}


@pytest.fixture(autouse=True)
def isolated_log(tmp_path, monkeypatch):
    """Every test writes its prediction log to its own temporary file, never to logs/predictions.db."""
    monkeypatch.setenv("PRICE_LOG", "1")
    monkeypatch.setenv("PRICE_LOG_DB", str(tmp_path / "test_predictions.db"))


@pytest.fixture(scope="session")
def art():
    import artifacts
    return artifacts.load_artifacts()


@pytest.fixture
def base():
    return dict(BASE)
