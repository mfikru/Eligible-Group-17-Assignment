import numpy as np
import pandas as pd
import pytest

import housing as h
import monitoring as mon
import prediction_log as plog


BASE = {"mae": 13_000, "rmsle": 0.11, "within_15pct": 0.87, "range_coverage": 0.76, "source": "test"}


def _log_rows(art, rows, outcomes=None):
    model, defaults, info = art
    for i, inp in enumerate(rows):
        out = h.safe_estimate(model, defaults, inp, info["holdout_rmsle"])
        rid = plog.log_prediction(inp, out, source="test", model_version="v", latency_ms=10.0)
        if outcomes is not None and rid and out["ok"]:
            plog.log_outcome(rid, outcomes[i])
    return plog.read_log()


@pytest.fixture(scope="module")
def reference():
    ref = mon.load_reference()
    if ref is None:
        pytest.skip("models/reference_stats.json missing (run python monitoring.py build-reference)")
    return ref


def test_psi_is_zero_for_identical_and_grows_with_shift():
    p = [0.1] * 10
    assert mon.psi(p, p) == pytest.approx(0, abs=1e-9)
    shifted = [0.0] * 5 + [0.2] * 5
    assert mon.psi(p, shifted) > mon.PSI_SIGNIFICANT
    assert mon.psi_status(0.05) == "stable" and mon.psi_status(0.15) == "moderate" and mon.psi_status(0.4) == "significant"


def test_reference_proportions_sum_to_one(reference):
    for r in reference["numeric"].values():
        assert sum(r["props"]) == pytest.approx(1.0)
    assert sum(reference["neighborhood"].values()) == pytest.approx(1.0)
    assert reference["n"] == 1458


def test_drift_needs_enough_data(art, base, reference):
    log = _log_rows(art, [base] * 5)
    assert not mon.drift_report(log, reference)["enough_data"]


def test_drift_detected_for_clearly_different_traffic(art, base, reference):
    rows = [{**base, "GrLivArea": 3500, "OverallQual": 10, "YearBuilt": 2009, "Neighborhood": "NridgHt"}] * 40
    d = mon.drift_report(_log_rows(art, rows), reference)
    assert d["enough_data"]
    assert d["features"]["GrLivArea"]["status"] == "significant"
    assert d["features"]["OverallQual"]["status"] == "significant"


def test_performance_alerts_when_estimates_are_far_off(art, base):
    rows = [{**base, "GrLivArea": 1200 + 20 * i} for i in range(25)]
    log = _log_rows(art, rows)
    far = (log["price"] * 0.6).tolist()  # actual prices 40% below the estimates
    for rid, a in zip(log["request_id"], far):
        plog.log_outcome(rid, a)
    perf = mon.performance_report(plog.read_log(), BASE)
    assert perf["enough_data"] and perf["alerts"]
    assert perf["metrics"]["median_bias_pct"] > 30


def test_performance_quiet_when_estimates_are_close(art, base):
    rows = [{**base, "GrLivArea": 1200 + 20 * i} for i in range(25)]
    log = _log_rows(art, rows)
    for rid, p in zip(log["request_id"], log["price"]):
        plog.log_outcome(rid, p * 1.02)
    perf = mon.performance_report(plog.read_log(), BASE)
    assert perf["enough_data"] and perf["alerts"] == [] and perf["metrics"]["within_15pct"] == 1.0


def test_performance_needs_enough_outcomes(art, base):
    assert not mon.performance_report(_log_rows(art, [base] * 3, [150_000] * 3), BASE)["enough_data"]


def test_operations_report_counts_rejections(art, base):
    log = _log_rows(art, [base, {**base, "GrLivArea": 50}, {**base, "Neighborhood": "Atlantis"}])
    ops = mon.operations_report(log)
    assert ops["requests"] == 3 and ops["rejected_share"] == pytest.approx(1 / 3) and ops["warning_share"] == pytest.approx(0.5)


def test_report_renders_with_empty_log(art, reference):
    text, alerts = mon.make_report(plog.read_log(), art[2], reference)
    assert "No requests logged yet" in text and alerts == []


def test_baseline_prefers_the_forms_own_accuracy():
    info = {"holdout_rmsle": 0.11, "range_coverage": 0.76,
            "targets_vs_achieved": {"mae_usd": {"holdout": 13_000}, "within_15pct": {"holdout": 0.87}}}
    app = {"mae": 17_500, "rmsle": 0.14, "within_15pct": 0.78, "range_coverage_with_own_range": 0.76}
    assert mon.baseline_from(info, app)["mae"] == 17_500
    assert mon.baseline_from(info, None)["mae"] == 13_000
    assert "all-feature" in mon.baseline_from(info, None)["source"]


def test_app_baseline_file_and_range_helper(art):
    import artifacts
    b = artifacts.load_app_baseline()
    assert b is not None and 0.12 < b["rmsle"] < 0.16 and b["within_15pct"] < art[2]["targets_vs_achieved"]["within_15pct"]["holdout"]
    assert artifacts.range_rmsle(art[2]) == b["rmsle"]
