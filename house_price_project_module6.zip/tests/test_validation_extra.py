import pytest

import housing as h


@pytest.mark.parametrize("bad", [5, 5.5, True, ["NAmes"], {"a": 1}, "x" * 61])
def test_non_text_or_overlong_neighbourhood_is_rejected(art, base, bad):
    _, defaults, info = art
    out = h.safe_estimate(art[0], defaults, {**base, "Neighborhood": bad}, info["holdout_rmsle"])
    assert not out["ok"] and any("Neighbourhood must be text" in e for e in out["errors"])


def test_text_neighbourhoods_still_work(art, base):
    model, defaults, info = art
    assert h.safe_estimate(model, defaults, {**base, "Neighborhood": " nAMES "}, info["holdout_rmsle"])["ok"]
    out = h.safe_estimate(model, defaults, {**base, "Neighborhood": "Atlantis"}, info["holdout_rmsle"])
    assert out["ok"] and out["warnings"]
